<!-- src/components/PackageDetailsModalAdminEvents.vue -->
<template>
  <div v-if="isOpen" class="modal-overlay">
    <div class="modal-content" :class="{ show: isOpen }">
      <button @click="$emit('close')" class="close-btn">✖</button>
      <h2 class="modal-title">Event Details</h2>
      <div v-if="eventData">
        <h3 class="package-name">{{ eventData.package_name || "N/A" }}</h3>
        <p>
          <strong>Package Type:</strong> {{ eventData.event_type || "N/A" }}
        </p>
        <p>
          <strong>Event Date:</strong>
          {{ formatDate(eventData.event_date) || "N/A" }}
        </p>
        <p><strong>Client:</strong> {{ eventData.full_name || "N/A" }}</p>
        <p><strong>Venue:</strong> {{ eventData.venue || "N/A" }}</p>
        <p>
          <strong>Package Category:</strong> {{ eventData.category || "N/A" }}
        </p>
        <p>
          <strong>Expected Guests:</strong>
          {{ eventData.expected_guests || "N/A" }}
        </p>
        <p><strong>Status:</strong> {{ eventData.status || "N/A" }}</p>
        <p>
          <strong>Price:</strong> ₱{{
            eventData.price ? eventData.price.toLocaleString() : "N/A"
          }}
        </p>
        <p>
          <strong>Additional Informations/Notes:</strong>
          {{ eventData.notes || "N/A" }}
        </p>
      </div>
    </div>
  </div>
</template>

<script setup>
import { defineProps } from "vue";

const props = defineProps({
  isOpen: Boolean,
  packageData: Object,
  eventData: Object,
});

const formatDate = (dateString) => {
  const options = { year: "numeric", month: "long", day: "numeric" };
  return new Date(dateString).toLocaleDateString(undefined, options);
};
</script>

<style scoped>
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.8);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000; /* Ensure this is high enough */
}

.modal-content {
  background-color: white;
  padding: 2rem;
  border-radius: 12px;
  max-width: 600px;
  width: 90%;
  position: relative;
  box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2);
  transition: transform 0.3s ease, opacity 0.3s ease;
  opacity: 1; /* Ensure opacity is set to 1 */
  transform: translateY(0); /* Ensure transform is reset */
}

.modal-content.show {
  opacity: 1; /* Ensure opacity is 1 when shown */
  transform: translateY(0); /* Ensure it is in the correct position */
}

.close-btn {
  position: absolute;
  top: 15px;
  right: 15px;
  width: 35px;
  height: 35px;
  background-color: #ff4d4d; /* Red color for close button */
  color: white;
  border: none;
  border-radius: 50%;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 18px;
  transition: background-color 0.3s ease;
}

.close-btn:hover {
  background-color: #ff1a1a; /* Darker red on hover */
}

.modal-title {
  font-size: 1.8rem;
  margin-bottom: 1rem;
  color: #333;
  text-align: center;
}

.package-name {
  font-size: 1.4rem;
  font-weight: bold;
  margin: 0.5rem 0;
  color: #007bff; /* Blue color for package name */
  text-align: center;
}

p {
  margin: 0.5rem 0;
  color: #555;
  line-height: 1.5;
}
</style>
