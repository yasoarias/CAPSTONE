<template>
  <div class="booked-history-page">
    <Navbar
      @openLoginModal="openLoginModal"
      @openRegisterModal="openRegisterModal"
      @logout="handleLogout"
    />
    <h1>Booked History</h1>
    <div class="recent-bookings">
      <h2>Recent Bookings</h2>
      <table>
        <thead>
          <tr>
            <th>Booking ID</th>
            <th>Package ID</th>
            <th>Package Category</th>
            <th>Package Type</th>
            <th>Package Price</th>
            <th>Event Date</th>
            <th>Venue</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="booking in paginatedBookings" :key="booking.id">
            <td>{{ booking.id }}</td>
            <td>{{ booking.package_id || "N/A" }}</td>
            <td>{{ booking.package_name || "N/A" }}</td>
            <td>{{ booking.event_type || "N/A" }}</td>
            <td>{{ booking.package_price ? formatPrice(booking.package_price) : '₱0.00' }}</td>
            <td>{{ formatDate(booking.event_date) }}</td>
            <td>{{ booking.venue_name }}</td>
            <td>{{ booking.status }}</td>
            <td>
              <button @click="viewBookingDetails(booking)" class="btn-details">
                Details
              </button>
              <button
                v-if="booking.status === 'Pending'"
                @click="cancelBooking(booking)"
                class="btn-cancel"
              >
                Cancel
              </button>
            </td>
          </tr>
        </tbody>
      </table>
      <div class="pagination">
        <button
          @click="prevPage"
          :disabled="currentPage === 1"
          class="btn-pagination"
        >
          Previous
        </button>
        <span>Page {{ currentPage }} of {{ totalPages }}</span>
        <button
          @click="nextPage"
          :disabled="currentPage === totalPages"
          class="btn-pagination"
        >
          Next
        </button>
      </div>
    </div>
    <BookingDetailsModal
      v-if="selectedBooking"
      :booking="selectedBooking"
      @close="closeBookingDetailsModal"
    />
    <div v-if="showCancelAnimation" class="cancel-animation-overlay">
      <div class="cancel-animation-content">
        <div class="checkmark-circle">
          <div class="checkmark"></div>
        </div>
        <h2>Booking Cancelled!</h2>
        <p>Your booking has been successfully cancelled.</p>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, watch } from "vue";
import Navbar from "@/components/Navbar.vue";
import { useAuth } from "../composables/useAuth";
import BookingDetailsModal from "@/components/BookingDetailsModal.vue";

const { token } = useAuth();

const bookings = ref([]);
const currentPage = ref(1);
const itemsPerPage = 10;

const filteredBookings = computed(() => {
  return bookings.value.filter(booking => booking.status !== 'Cancelled');
});

const paginatedBookings = computed(() => {
  const start = (currentPage.value - 1) * itemsPerPage;
  const end = start + itemsPerPage;
  return filteredBookings.value.slice(start, end);
});

const totalPages = computed(() =>
  Math.ceil(filteredBookings.value.length / itemsPerPage)
);

const nextPage = () => {
  if (currentPage.value < totalPages.value) {
    currentPage.value++;
  }
};

const prevPage = () => {
  if (currentPage.value > 1) {
    currentPage.value--;
  }
};

const formatDate = (dateString) => {
  const options = { year: "numeric", month: "long", day: "numeric" };
  return new Date(dateString).toLocaleDateString(undefined, options);
};

const openLoginModal = () => {
  // Implementation
};

const openRegisterModal = () => {
  // Implementation
};

const handleLogout = () => {
  // Implementation
};

const fetchBookings = async () => {
  try {
    const response = await fetch("http://localhost:3000/api/bookings", {
      headers: {
        Authorization: `Bearer ${token.value}`,
      },
    });
    if (response.ok) {
      const data = await response.json();
      console.log('Received bookings data:', data); // Debug log
      // Verify each booking has an id
      data.forEach(booking => {
        if (!booking.id) {
          console.warn('Booking missing ID:', booking);
        }
      });
      bookings.value = data;
    } else {
      console.error("Failed to fetch bookings");
    }
  } catch (error) {
    console.error("Error fetching bookings:", error);
  }
};

const viewBookingDetails = (booking) => {
  selectedBooking.value = booking;
};

const cancelBooking = async (booking) => {
  try {
    const packageId = booking.package_id;
    console.log("Attempting to cancel booking:", booking);

    if (!packageId || packageId <= 0) {
      throw new Error(`Invalid package ID: ${packageId}`);
    }

    if (!token.value) {
      throw new Error("No authentication token found");
    }

    const response = await fetch(
      `http://localhost:3000/api/bookings/${packageId}/cancel`,
      {
        method: "PUT",
        headers: {
          "Authorization": token.value,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          created_at: booking.created_at
        })
      }
    );

    const data = await response.json();
    
    if (!response.ok) {
      throw new Error(data.message || "Failed to cancel booking");
    }

    // Show animation
    showCancelAnimation.value = true;

    // Wait for animation and then reload
    setTimeout(async () => {
      await fetchBookings();
      showCancelAnimation.value = false;
      window.location.reload();
    }, 2000); // 2 seconds delay

  } catch (error) {
    console.error("Error cancelling booking:", error);
    alert(error.message || "Failed to cancel booking");
  }
};

const closeBookingDetailsModal = () => {
  selectedBooking.value = null;
};

const selectedBooking = ref(null);

const formatPrice = (price) => {
  // Check if price is null, undefined, or not a number
  if (!price || isNaN(price)) {
    return '₱0.00';
  }
  
  // Convert string to number if needed
  const numericPrice = typeof price === 'string' ? parseFloat(price) : price;
  
  // Format the price with PHP currency
  return new Intl.NumberFormat('en-PH', {
    style: 'currency',
    currency: 'PHP',
    minimumFractionDigits: 2,
    currencyDisplay: 'symbol'
  }).format(numericPrice).replace('PHP', '₱');
};

onMounted(() => {
  if (!token.value) {
    console.error("No token found");
    // Redirect to login or handle unauthorized state
    return;
  }
  fetchBookings();
});

watch(paginatedBookings, (newBookings) => {
  console.log('Paginated bookings:', newBookings);
}, { deep: true });

// Add new ref for animation control
const showCancelAnimation = ref(false);
</script>

<style scoped>
.booked-history-page {
  padding: 2rem;
}

h1,
h2 {
  margin-bottom: 1rem;
}

table {
  width: 100%;
  border-collapse: collapse;
  margin-bottom: 1rem;
}

th,
td {
  padding: 0.75rem;
  text-align: left;
  border-bottom: 1px solid #ddd;
}

th {
  background-color: #f2f2f2;
  font-weight: bold;
}

.pagination {
  display: flex;
  justify-content: center;
  align-items: center;
  margin-top: 1rem;
}

.btn-pagination {
  background-color: #007bff;
  color: white;
  border: none;
  padding: 0.5rem 1rem;
  margin: 0 0.5rem;
  cursor: pointer;
  border-radius: 4px;
}

.btn-pagination:disabled {
  background-color: #ccc;
  cursor: not-allowed;
}

.btn-details,
.btn-cancel {
  padding: 0.25rem 0.5rem;
  margin: 0 0.25rem;
  border: none;
  border-radius: 0.25rem;
  cursor: pointer;
  font-size: 0.875rem;
}

.btn-details {
  background-color: #3498db;
  color: white;
}

.btn-cancel {
  background-color: #e74c3c;
  color: white;
}

.btn-details:hover,
.btn-cancel:hover {
  opacity: 0.8;
}

/* Animation overlay */
.cancel-animation-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.7);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
  animation: fadeIn 0.3s ease-out;
}

.cancel-animation-content {
  background: white;
  padding: 2rem;
  border-radius: 1rem;
  text-align: center;
  animation: slideIn 0.5s ease-out;
}

.checkmark-circle {
  width: 80px;
  height: 80px;
  position: relative;
  display: inline-block;
  vertical-align: top;
  margin: 20px;
}

.checkmark {
  border-radius: 50%;
  position: absolute;
  top: 0;
  left: 0;
  height: 80px;
  width: 80px;
  background: #4CAF50;
  animation: fill .4s ease-in-out .4s forwards, scale .3s ease-in-out .9s both;
}

.checkmark:before {
  content: '';
  position: absolute;
  border-right: 4px solid white;
  border-bottom: 4px solid white;
  width: 22px;
  height: 40px;
  top: 14px;
  left: 29px;
  transform: rotate(45deg);
  animation: checkmark 0.8s ease-in-out forwards;
}

@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

@keyframes slideIn {
  from {
    transform: translateY(-20px);
    opacity: 0;
  }
  to {
    transform: translateY(0);
    opacity: 1;
  }
}

@keyframes fill {
  100% { box-shadow: inset 0 0 0 80px #4CAF50; }
}

@keyframes scale {
  0%, 100% { transform: none; }
  50% { transform: scale3d(1.1, 1.1, 1); }
}

@keyframes checkmark {
  0% {
    height: 0;
    width: 0;
    opacity: 0;
  }
  40% {
    height: 0;
    width: 22px;
    opacity: 1;
  }
  100% {
    height: 40px;
    width: 22px;
    opacity: 1;
  }
}

/* Make it responsive */
@media (max-width: 768px) {
  .cancel-animation-content {
    width: 90%;
    max-width: 400px;
    padding: 1.5rem;
  }

  .checkmark-circle {
    width: 60px;
    height: 60px;
    margin: 15px;
  }

  .checkmark {
    height: 60px;
    width: 60px;
  }

  .checkmark:before {
    width: 18px;
    height: 32px;
    top: 10px;
    left: 22px;
  }

  .cancel-animation-content h2 {
    font-size: 1.5rem;
  }

  .cancel-animation-content p {
    font-size: 1rem;
  }
}

@media (max-width: 480px) {
  .cancel-animation-content {
    padding: 1rem;
  }

  .checkmark-circle {
    width: 50px;
    height: 50px;
    margin: 10px;
  }

  .checkmark {
    height: 50px;
    width: 50px;
  }

  .checkmark:before {
    width: 15px;
    height: 28px;
    top: 8px;
    left: 18px;
  }

  .cancel-animation-content h2 {
    font-size: 1.25rem;
  }

  .cancel-animation-content p {
    font-size: 0.875rem;
  }
}
</style>
