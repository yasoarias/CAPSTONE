<template>
  <div class="admin-dashboard">
    <AdminSidebar :class="{ 'show-menu': showMenu }" />
    <main>
      <button @click="toggleMenu" class="menu-btn">
        <span class="material-icons-sharp">menu</span>
      </button>
      <p>Dashboard</p>
      <div class="top-actions">
        <button @click="openPostModal" class="post-btn">
          <span class="material-icons-sharp">post_add</span>
          Post
        </button>
      </div>
      <div class="insights">
        <div class="sales">
          <span class="material-icons-sharp">group</span>
          <div class="middle">
            <div class="left">
              <h3>Total Users</h3>
              <h1>{{ userCount }}</h1>
            </div>
          </div>
          <small class="text-muted">Total registered users</small>
        </div>
        <div class="expenses">
          <span class="material-icons-sharp">bar_chart</span>
          <div class="middle">
            <div class="left">
              <h3>Total Requests</h3>
              <h1>50</h1>
            </div>
          </div>
          <small class="text-muted">Last 24 hours</small>
        </div>
        <div class="income">
          <span class="material-icons-sharp">stacked_line_chart</span>
          <div class="middle">
            <div class="left">
              <h3>Pending Reservation</h3>
              <h1>54</h1>
            </div>
          </div>
          <small class="text-muted">Last 24 hours</small>
        </div>
      </div>
      <div class="calendar-section">
        <h2>Calendar Overview</h2>
        <div class="calendar-container">
          <div v-if="isLoading" class="loading">Loading calendar...</div>
          <div v-else>
            <div class="calendar-header">
              <button @click="prevMonth" class="nav-btn">
                <span class="material-icons-sharp">chevron_left</span>
              </button>
              <h3>{{ currentMonthYear }}</h3>
              <button @click="nextMonth" class="nav-btn">
                <span class="material-icons-sharp">chevron_right</span>
              </button>
            </div>
            <div class="calendar">
              <div class="weekdays">
                <div v-for="day in weekDays" :key="day">{{ day }}</div>
              </div>
              <div class="days">
                <div
                  v-for="day in calendarDays"
                  :key="day.date"
                  class="day"
                  :class="{
                    'other-month': !day.isCurrentMonth,
                    'has-events': day.events.length > 0,
                  }"
                  @click="handleDayClick(day)"
                >
                  <span class="date">{{ new Date(day.date).getDate() }}</span>
                  <div class="day-events">
                    <div
                      v-for="event in day.events"
                      :key="event.id"
                      class="event-item"
                      :title="`${event.event_type} - ${event.full_name}`"
                    >
                      <div class="event-dot"></div>
                      <span class="event-time">
                        {{ formatEventTime(event.event_date) }}
                      </span>
                      <span class="event-title">{{ event.event_type }}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
    <div class="right">
      <div class="top">
        <button id="menu-btn">
          <span class="material-icons-sharp">menu</span>
        </button>
        <div class="theme-toggler">
          <span class="material-icons-sharp active">light_mode</span>
          <span class="material-icons-sharp">dark_mode</span>
        </div>
        <div class="profile">
          <div class="profile-photo">
            <img src="@/assets/profile-1.jpg" alt="Profile" />
          </div>
        </div>
      </div>
      <div class="recent-updates">
        <h2>Users Updates</h2>
        <div class="updates">
          <div class="update" v-for="update in recentUpdates" :key="update.id">
            <div class="profile-photo">
              <img
                :src="update.image"
                :alt="update.name"
                @error="update.image = defaultProfileImage"
              />
            </div>
            <div class="message">
              <p>
                <strong>{{ update.name }}</strong> {{ update.message }}
              </p>
              <small class="text-muted">{{ update.time }}</small>
            </div>
          </div>
        </div>
        <div class="pagination">
          <button
            @click="prevPage"
            :disabled="currentPage === 1"
            class="pagination-button"
          >
            Previous
          </button>
          <span>Page {{ currentPage }} of {{ totalPages }}</span>
          <button
            @click="nextPage"
            :disabled="currentPage === totalPages"
            class="pagination-button"
          >
            Next
          </button>
        </div>
      </div>
      <div class="sales-analytics">
        <h2>Activities</h2>
        <div class="item online">
          <div class="icon">
            <span class="material-icons-sharp">shopping_cart</span>
          </div>
          <div class="right">
            <div class="info">
              <h3>Recent Added Packages</h3>
              <small class="text-muted">Last 24 hours</small>
            </div>
            <h5 class="success">+39%</h5>
            <h3>3849</h3>
          </div>
        </div>
        <div class="item offline">
          <div class="icon">
            <span class="material-icons-sharp">local_mall</span>
          </div>
          <div class="right">
            <div class="info">
              <h3>OFFLINE ORDERS</h3>
              <small class="text-muted">Last 24 hours</small>
            </div>
            <h5 class="danger">-17%</h5>
            <h3>1100</h3>
          </div>
        </div>
        <div class="item customers">
          <div class="icon">
            <span class="material-icons-sharp">person</span>
          </div>
          <div class="right">
            <div class="info">
              <h3>NEW CUSTOMERS</h3>
              <small class="text-muted">Last 24 hours</small>
            </div>
            <h5 class="success">+25%</h5>
            <h3>849</h3>
          </div>
        </div>
        <div class="item add-product" @click="openAddProductModal">
          <div>
            <span class="material-icons-sharp">add</span>
            <h3>Add Product</h3>
          </div>
        </div>
      </div>
    </div>
    <!-- Add this line to include the modal -->
    <AddProductModal
      :isOpen="isAddProductModalOpen"
      @close="closeAddProductModal"
    />
    <!-- Add this line to include the Post modal -->
    <PostModal v-if="isPostModalOpen" @close="closePostModal" />
    <!-- Add this at the bottom of your template before closing main tag -->
    <PackageDetailsModalAdminEvents
      v-if="isModalOpen"
      :isOpen="isModalOpen"
      :packageData="selectedPackage"
      :eventData="selectedEvent"
      @close="closeModal"
    />
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from "vue";
import { useRouter } from "vue-router";
import AdminSidebar from "./AdminSidebar.vue";
import AddProductModal from "./AddProductModal.vue";
import PostModal from "./PostModal.vue";
import defaultProfileImage from "@/assets/default-profile.png";
import { useAuth } from "../composables/useAuth";
import PackageDetailsModalAdminEvents from "./PackageDetailsModalAdminEvents.vue";

const router = useRouter();
const { token } = useAuth();

// Basic refs
const userCount = ref(0);
const recentUpdates = ref([]);
const isAddProductModalOpen = ref(false);
const isPostModalOpen = ref(false);
const currentPage = ref(1);
const usersPerPage = 3;
const totalPages = ref(1);
const showMenu = ref(false);

// Calendar refs
const isLoading = ref(true);
const currentDate = ref(new Date());
const events = ref([]);
const weekDays = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

// Add these refs
const selectedEvent = ref(null);
const isModalOpen = ref(false);
const selectedPackage = ref(null);

// Calendar computed properties
const currentMonthYear = computed(() => {
  return currentDate.value.toLocaleDateString("en-US", {
    month: "long",
    year: "numeric",
  });
});

const calendarDays = computed(() => {
  const year = currentDate.value.getFullYear();
  const month = currentDate.value.getMonth();
  const firstDay = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0);
  const daysInMonth = lastDay.getDate();
  const startPadding = firstDay.getDay();

  const days = [];

  // Previous month padding
  const daysInPrevMonth = new Date(year, month, 0).getDate();
  for (let i = startPadding - 1; i >= 0; i--) {
    const date = new Date(year, month - 1, daysInPrevMonth - i);
    days.push({
      date: date.toISOString(),
      isCurrentMonth: false,
      events: getEventsForDate(date),
    });
  }

  // Current month
  for (let i = 1; i <= daysInMonth; i++) {
    const date = new Date(year, month, i);
    days.push({
      date: date.toISOString(),
      isCurrentMonth: true,
      events: getEventsForDate(date),
    });
  }

  // Next month padding
  const remainingDays = 42 - days.length;
  for (let i = 1; i <= remainingDays; i++) {
    const date = new Date(year, month + 1, i);
    days.push({
      date: date.toISOString(),
      isCurrentMonth: false,
      events: getEventsForDate(date),
    });
  }

  return days;
});

// Calendar methods
const getEventsForDate = (date) => {
  return events.value.filter((event) => {
    const eventDate = new Date(event.event_date);
    return eventDate.toDateString() === date.toDateString();
  });
};

const fetchEvents = async () => {
  try {
    isLoading.value = true;
    const response = await fetch("http://localhost:3000/api/bookings", {
      headers: {
        Authorization: `Bearer ${token.value}`,
      },
    });

    if (!response.ok) throw new Error("Failed to fetch events");

    const data = await response.json();
    events.value = data
      .filter((event) => event.status === "Accepted")
      .map((event) => ({
        id: event.id,
        event_type: event.event_type,
        event_date: event.event_date,
        full_name: event.full_name,
        expected_guests: event.expected_guests,
        package_name: event.package_name,
        package_id: event.package_id,
        status: event.status,
      }));
  } catch (error) {
    console.error("Error fetching events:", error);
  } finally {
    isLoading.value = false;
  }
};

const prevMonth = () => {
  currentDate.value = new Date(
    currentDate.value.getFullYear(),
    currentDate.value.getMonth() - 1,
    1
  );
};

const nextMonth = () => {
  currentDate.value = new Date(
    currentDate.value.getFullYear(),
    currentDate.value.getMonth() + 1,
    1
  );
};

// Initialize
onMounted(() => {
  fetchUsers();
  fetchEvents();
});

const fetchUsers = async (page = 1) => {
  try {
    const token = localStorage.getItem("token");
    const response = await fetch(
      `http://localhost:3000/api/users?page=${page}&limit=${usersPerPage}`,
      {
        headers: {
          Authorization: token,
        },
      }
    );
    if (!response.ok) {
      throw new Error(`Failed to fetch users: ${response.status}`);
    }
    const data = await response.json();

    userCount.value = data.total;
    totalPages.value = Math.ceil(data.total / usersPerPage);
    recentUpdates.value = data.users.map((user) => ({
      id: user.id,
      name: user.fullName,
      image: user.profilePicture
        ? `http://localhost:3000${user.profilePicture}`
        : defaultProfileImage, // Use imported default image
      message: `is a ${user.role} on our platform.`,
      time: new Date(user.createdAt).toLocaleDateString(),
    }));
  } catch (error) {
    console.error("Error fetching users:", error);
    userCount.value = 0;
    recentUpdates.value = [];
  }
};

const nextPage = () => {
  if (currentPage.value < totalPages.value) {
    currentPage.value++;
    fetchUsers(currentPage.value);
  }
};

const prevPage = () => {
  if (currentPage.value > 1) {
    currentPage.value--;
    fetchUsers(currentPage.value);
  }
};

const toggleMenu = () => {
  showMenu.value = !showMenu.value;
};

const openPostModal = () => {
  isPostModalOpen.value = true;
};

const closePostModal = () => {
  isPostModalOpen.value = false;
};

// Add this function before the component setup
const formatEventTime = (timestamp) => {
  const date = new Date(timestamp);
  return date.toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  });
};

// ... rest of your script

const handleDayClick = async (day) => {
  if (day.events.length > 0) {
    const event = day.events[0];
    try {
      if (!event.package_id) {
        console.error("No package ID found for event:", event);
        return;
      }

      const response = await fetch(
        `http://localhost:3000/api/products/${event.package_id}`,
        {
          headers: {
            Authorization: `Bearer ${token.value}`,
          },
        }
      );

      if (!response.ok) throw new Error("Failed to fetch package details");

      const packageData = await response.json();
      if (packageData.image_path) {
        packageData.image = `http://localhost:3000${packageData.image_path}`;
      }

      selectedPackage.value = packageData;
      selectedEvent.value = event;
      isModalOpen.value = true;
    } catch (error) {
      console.error("Error fetching package details:", error);
    }
  }
};

// Add this method to close the modal
const closeModal = () => {
  isModalOpen.value = false;
  selectedPackage.value = null;
  selectedEvent.value = null;
};
</script>
