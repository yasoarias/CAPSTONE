-- java Script


              function httpGetAsync(url, callback) {
                  const xmlHttp = new XMLHttpRequest();
                  xmlHttp.onreadystatechange = function() {
                      if (xmlHttp.readyState === 4 && xmlHttp.status === 200)
                      callback(xmlHttp.responseText);
                  }
                  xmlHttp.open("GET", url, true); // true for asynchronous
                  xmlHttp.send(null);
              }

              const url = "https://emailvalidation.abstractapi.com/v1/?api_key=c367615eccc34d96ba62bedc4d5af7a6&email=limitlessinfinity2111@gmail.com"

              httpGetAsync(url)

-- NodeJs


              const axios = require('axios');
              axios.get('https://emailvalidation.abstractapi.com/v1/?api_key=c367615eccc34d96ba62bedc4d5af7a6&email=limitlessinfinity2111@gmail.com')
                  .then(response => {
                      console.log(response.data);
                  })
                  .catch(error => {
                      console.log(error);
                  });

                  
-- Java


              import java.io.IOException;
              import org.apache.http.client.fluent.*;

              public class makeAbstractRequest
              {
              public static void main(String[] args) {
                  makeAbstractRequest();
              }

              private static void makeAbstractRequest() {

                  try {

                      Content content = Request.Get('https://emailvalidation.abstractapi.com/v1/?api_key=c367615eccc34d96ba62bedc4d5af7a6&email=limitlessinfinity2111@gmail.com')

                      .execute().returnContent();

                      System.out.println(content);
                  }
                  catch (IOException error) { System.out.println(error); }
              }
              }