<template>
  <div>
    <router-view v-if="isAuthorized" />
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { useRouter } from 'vue-router';

const isAuthorized = ref(false);
const router = useRouter();

onMounted(() => {
  const userRole = localStorage.getItem('userRole'); // Assuming user role is stored in localStorage

  if (userRole === 'admin' || userRole === 'user') {
    isAuthorized.value = true;
  } else {
    router.push('/login'); // Redirect to login if not authorized
  }
});
</script>
