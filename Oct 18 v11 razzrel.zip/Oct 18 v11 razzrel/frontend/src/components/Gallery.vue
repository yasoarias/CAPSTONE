<template>
  <div class="gallery-page" :class="{ 'dark-mode': isDarkMode }">
    <Navbar 
      @openLoginModal="openLoginModal"
      @openRegisterModal="openRegisterModal"
      @logout="handleLogout"
    />
    <div class="content-wrapper">
      <main>
        <h1 class="gallery-title">Latest Posts</h1>
        <div class="posts-grid">
          <div v-for="post in posts" :key="post.id" class="post-item">
            <div class="post-header">
              <img :src="getProfilePicture(post.user_id)" alt="User Avatar" class="user-avatar">
              <span class="user-name">{{ post.userName }}</span>
              <span class="post-date">{{ formatDate(post.created_at) }}</span>
            </div>
            <img v-if="post.images" :src="getImageUrl(post.images.split(',')[0])" :alt="post.content" class="post-image" />
            <div class="post-info">
              <p class="post-content">{{ truncateContent(post.content) }}</p>
            </div>
            <div class="post-actions">
              <button class="action-btn like-btn">
                <i class="fas fa-heart"></i> Like
              </button>
              <button class="action-btn comment-btn">
                <i class="fas fa-comment"></i> Comment
              </button>
              <button class="action-btn share-btn">
                <i class="fas fa-share"></i> Share
              </button>
            </div>
          </div>
        </div>
      </main>
    </div>

    <!-- Login and Register modals -->
    <Login v-if="isModalOpen && activeModal === 'login'" :isOpen="isModalOpen" @close="closeModal" @login="handleLogin" @switchToRegister="switchToRegister" />
    <Register v-if="isModalOpen && activeModal === 'register'" :isOpen="isModalOpen" @close="closeModal" @register="handleRegister" @switchToLogin="switchToLogin" />
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import Navbar from "./Navbar.vue";
import Login from "./login.vue";
import Register from "./register.vue";
import { useAuth } from '@/composables/useAuth';

const { token } = useAuth();

const isDarkMode = ref(false);
const isLoggedIn = ref(false);
const isModalOpen = ref(false);
const activeModal = ref("login");
const posts = ref([]);

onMounted(() => {
  isLoggedIn.value = !!localStorage.getItem('token');
  fetchPosts();
});

const fetchPosts = async () => {
  try {
    const response = await fetch('http://localhost:3000/api/posts', {
      headers: {
        'Authorization': token.value
      }
    });
    if (response.ok) {
      posts.value = await response.json();
    } else {
      console.error('Failed to fetch posts');
    }
  } catch (error) {
    console.error('Error fetching posts:', error);
  }
};

const getImageUrl = (imagePath) => {
  return `http://localhost:3000/uploads/${imagePath}`;
};

const getProfilePicture = (userId) => {
  // Replace this with actual logic to get user's profile picture
  return `https://api.dicebear.com/6.x/initials/svg?seed=user${userId}`;
};

const truncateContent = (content, maxLength = 150) => {
  if (content.length <= maxLength) return content;
  return content.slice(0, maxLength) + '...';
};

const formatDate = (dateString) => {
  const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' };
  return new Date(dateString).toLocaleDateString(undefined, options);
};

const handleLogout = () => {
  localStorage.removeItem('token');
  isLoggedIn.value = false;
};

const openLoginModal = () => {
  isModalOpen.value = true;
  activeModal.value = "login";
};

const openRegisterModal = () => {
  isModalOpen.value = true;
  activeModal.value = "register";
};

const closeModal = () => {
  isModalOpen.value = false;
};

const handleLogin = (credentials) => {
  console.log("Login credentials received:", credentials);
  closeModal();
};

const handleRegister = (userData) => {
  console.log("Registration data received:", userData);
  closeModal();
};

const switchToRegister = () => {
  activeModal.value = "register";
};

const switchToLogin = () => {
  activeModal.value = "login";
};
</script>

<style scoped>
.gallery-page {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
  background-color: #f0f2f5;
}

.content-wrapper {
  display: flex;
  flex: 1;
  padding: 20px;
  max-width: 800px;
  margin: 0 auto;
  width: 100%;
}

main {
  flex: 1;
}

.gallery-title {
  margin-bottom: 20px;
  font-size: 24px;
  color: #1877f2;
}

.posts-grid {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.post-item {
  background-color: white;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
}

.post-header {
  display: flex;
  align-items: center;
  padding: 12px;
}

.user-avatar {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  margin-right: 10px;
}

.user-name {
  font-weight: bold;
  margin-right: 10px;
}

.post-date {
  font-size: 0.8em;
  color: #65676b;
}

.post-image {
  width: 100%;
  max-height: 500px;
  object-fit: cover;
}

.post-info {
  padding: 12px;
}

.post-content {
  margin-bottom: 10px;
  line-height: 1.4;
}

.post-actions {
  display: flex;
  justify-content: space-around;
  padding: 8px;
  border-top: 1px solid #e4e6eb;
}

.action-btn {
  background: none;
  border: none;
  color: #65676b;
  font-size: 14px;
  font-weight: 600;
  padding: 8px;
  cursor: pointer;
  transition: background-color 0.3s;
}

.action-btn:hover {
  background-color: #f0f2f5;
  border-radius: 4px;
}

/* Dark mode styles */
.dark-mode {
  background-color: #18191a;
  color: #e4e6eb;
}

.dark-mode .post-item {
  background-color: #242526;
}

.dark-mode .post-date,
.dark-mode .action-btn {
  color: #b0b3b8;
}

.dark-mode .post-actions {
  border-top-color: #3e4042;
}

.dark-mode .action-btn:hover {
  background-color: #3a3b3c;
}
</style>
