const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql2');
const cors = require('cors'); // Import the cors package
const fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args));
const jwt = require('jsonwebtoken'); // You'll need to install this package
const bcrypt = require('bcrypt'); // You'll need to install this package
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const app = express();
const port = 3000;
const newverifyToken = (req, res, next) => {
  const token = req.headers['authorization']?.split(' ')[1]; // Extract token from header
  if (!token) return res.status(403).json({ message: "No token provided" });

  jwt.verify(token, JWT_SECRET, (err, decoded) => {
      if (err) return res.status(401).json({ message: "Unauthorized" });
      req.user = decoded; // Attach user info to request
      next();
  });
};


// Middleware
app.use(bodyParser.json());
app.use(cors()); // Use the cors middleware

// MySQL connection
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'erms'
});

db.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL:', err);
    return;
  }
  console.log('Connected to MySQL');
});

// Secret key for JWT
const JWT_SECRET = 'arias123'; // Change this to a secure random string

// Configure multer for file upload
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/') // Make sure this directory exists
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + path.extname(file.originalname))
  }
});

const upload = multer({ storage: storage });

// Serve uploaded files statically
app.use('/uploads', express.static('uploads'));

// Middleware to verify JWT token
const verifyToken = (req, res, next) => {
  const token = req.headers['authorization'];
  if (!token) return res.status(403).json({ message: "No token provided" });

  jwt.verify(token, JWT_SECRET, (err, decoded) => {
    if (err) return res.status(401).json({ message: "Unauthorized" });
    req.user = decoded;
    next();
  });
};

// Middleware to check if user is authenticated
const isUser = (req, res, next) => {
  if (!req.user) return res.status(403).json({ message: "No user authenticated" });
  next();
};

// Middleware to check if user is admin
const isAdmin = (req, res, next) => {
  if (!req.user || req.user.role !== 'admin') return res.status(403).json({ message: "Require Admin Role!" });
  next();
};

// Public Routes
app.post('/register', async (req, res) => {
  try {
    const { fullName, email, password, contactNo, termsAccepted } = req.body;
    
    const hashedPassword = await bcrypt.hash(password, 10);

    const query = 'INSERT INTO users (role, fullName, email, password, contactNo, termsAccepted) VALUES (?, ?, ?, ?, ?, ?)';
    db.query(query, ['user', fullName, email, hashedPassword, contactNo, termsAccepted], (err, result) => {
      if (err) {
        console.error('Error inserting data into MySQL:', err);
        if (err.code === 'ER_DUP_ENTRY') {
          res.status(400).json({ success: false, message: 'Email already exists' });
        } else {
          res.status(500).json({ success: false, message: 'Database error' });
        }
        return;
      }
      res.json({ success: true, message: 'User registered successfully' });
    });
  } catch (error) {
    console.error('Error during registration:', error);
    res.status(500).json({ success: false, message: 'An error occurred during registration' });
  }
});

app.post('/login', (req, res) => {
  console.log('Login request received:', req.body);
  const { email, password } = req.body;
  const query = 'SELECT * FROM users WHERE email = ?';
  console.log('Executing query:', query, 'with email:', email);
  db.query(query, [email], async (err, results) => {
    if (err) {
      console.error('Database error:', err);
      res.status(500).json({ message: "Error on the server." });
      return;
    }
    console.log('Query results:', results);
    if (results.length === 0) {
      console.log('User not found:', email);
      res.status(404).json({ message: "User not found." });
      return;
    }
    const user = results[0];
    const passwordIsValid = await bcrypt.compare(password, user.password);
    if (!passwordIsValid) {
      console.log('Invalid password for user:', email);
      res.status(401).json({ message: "Invalid password!" });
      return;
    }
    const token = jwt.sign(
      { 
        id: user.id, 
        fullName: user.fullName, 
        email: user.email, 
        role: user.role,
        contactNo: user.contactNo,
        profilePicture: user.profilePicture // Add this line
      }, 
      JWT_SECRET, 
      { expiresIn: 86400 } // 24 hours
    );
    console.log('Login successful for user:', email);
    res.status(200).json({ 
      auth: true, 
      token: token, 
      user: { 
        id: user.id, 
        fullName: user.fullName, 
        email: user.email, 
        role: user.role,
        contactNo: user.contactNo,
        profilePicture: user.profilePicture // Add this line
      } 
    });
  });
});

// Private Routes
app.get('/user/profile', verifyToken, (req, res) => {
  const userId = req.user.id;
  console.log('Fetching profile for user ID:', userId);

  const query = 'SELECT id, role, fullName, email, contactNo, termsAccepted, created_at, createdAt, profilePicture FROM users WHERE id = ?';
  db.query(query, [userId], (err, results) => {
    if (err) {
      console.error('Error fetching user profile:', err);
      res.status(500).json({ message: "Error fetching user profile" });
      return;
    }

    if (results.length === 0) {
      console.log('No user found with ID:', userId);
      res.status(404).json({ message: "User not found" });
      return;
    }

    const user = results[0];
    console.log('Fetched user data:', user);
    res.json(user);
  });
});

app.get('/admin/users', verifyToken, isAdmin, (req, res) => {
  const query = 'SELECT id, fullName, email, role FROM users';
  db.query(query, (err, results) => {
    if (err) {
      res.status(500).json({ message: "Error on the server." });
      return;
    }
    res.status(200).json(results);
  });
});

// New API endpoint for fetching all users
app.get('/api/users', verifyToken, (req, res) => {
  const page = parseInt(req.query.page) || 1;
  const limit = parseInt(req.query.limit) || 5;
  const offset = (page - 1) * limit;

  console.log('Fetching users with page:', page, 'limit:', limit); // Debug log

  const countQuery = 'SELECT COUNT(*) as total FROM users';
  const dataQuery = 'SELECT id, fullName, email, role, createdAt, profilePicture FROM users ORDER BY createdAt DESC LIMIT ? OFFSET ?';

  db.query(countQuery, (countErr, countResults) => {
    if (countErr) {
      console.error('Error counting users:', countErr);
      return res.status(500).json({ message: "Error fetching users from the server." });
    }

    const total = countResults[0].total;
    console.log('Total users:', total); // Debug log

    db.query(dataQuery, [limit, offset], (dataErr, dataResults) => {
      if (dataErr) {
        console.error('Error fetching users:', dataErr);
        return res.status(500).json({ message: "Error fetching users from the server." });
      }

      console.log('Fetched users:', dataResults); // Debug log

      res.status(200).json({
        users: dataResults,
        total: total,
        page: page,
        totalPages: Math.ceil(total / limit)
      });
    });
  });
});

// New route to add a product (only for admin)
app.post('/api/products', verifyToken, isAdmin, upload.single('image'), (req, res) => {
  const { name, description, price, category } = req.body;
  const imagePath = req.file ? `/uploads/${req.file.filename}` : null;

  console.log('Received product data:', { name, description, price, category, imagePath });

  const query = 'INSERT INTO products (name, description, price, category, image_path) VALUES (?, ?, ?, ?, ?)';
  db.query(query, [name, description, price, category, imagePath], (err, result) => {
    if (err) {
      console.error('Error adding product:', err);
      res.status(500).json({ success: false, message: 'Error adding product' });
      return;
    }
    console.log('Product added successfully:', result);
    res.status(201).json({ success: true, message: 'Product added successfully', productId: result.insertId });
  });
});

// New route to get all products
app.get('/api/products', (req, res) => {
  const query = 'SELECT * FROM products';
  db.query(query, (err, results) => {
    if (err) {
      console.error('Error fetching products:', err);
      res.status(500).json({ message: "Error fetching products from the server." });
      return;
    }
    res.status(200).json(results);
  });
});

// Configure multer for profile picture uploads
const profileStorage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/profiles/') // Make sure this directory exists
  },
  filename: function (req, file, cb) {
    cb(null, 'profile-' + Date.now() + path.extname(file.originalname))
  }
});

const uploadProfile = multer({ storage: profileStorage });

// Serve profile pictures statically
app.use('/uploads/profiles', express.static('uploads/profiles'));

// Ensure uploads directory exists
const uploadsDir = path.join(__dirname, 'uploads', 'profiles');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Add this new endpoint for updating user information
app.post('/api/user/update', verifyToken, uploadProfile.single('profilePicture'), (req, res) => {
  const { fullName, email, contactNo } = req.body;
  const userId = req.user.id;
  const profilePicturePath = req.file ? `/uploads/profiles/${req.file.filename}` : null;

  console.log('Updating user:', userId);
  console.log('New data:', { fullName, email, contactNo, profilePicturePath });

  let updateQuery = 'UPDATE users SET fullName = ?, email = ?, contactNo = ?';
  let updateParams = [fullName, email, contactNo];

  if (profilePicturePath) {
    updateQuery += ', profilePicture = ?';
    updateParams.push(profilePicturePath);
  }

  updateQuery += ' WHERE id = ?';
  updateParams.push(userId);

  console.log('Update query:', updateQuery);
  console.log('Update params:', updateParams);

  db.query(updateQuery, updateParams, (err, result) => {
    if (err) {
      console.error('Error updating user information:', err);
      res.status(500).json({ success: false, message: 'Error updating user information' });
      return;
    }

    console.log('Update result:', result);

    const selectQuery = 'SELECT id, role, fullName, email, contactNo, termsAccepted, created_at, createdAt, profilePicture FROM users WHERE id = ?';
    db.query(selectQuery, [userId], (err, results) => {
      if (err) {
        console.error('Error fetching updated user information:', err);
        res.status(500).json({ success: false, message: 'Error fetching updated user information' });
        return;
      }

      const updatedUser = results[0];
      // Remove sensitive information
      delete updatedUser.password;
      
      res.status(200).json({ success: true, message: 'User information updated successfully', user: updatedUser });
    });
  });
});

// Updated route to rate a product and add feedback
app.post('/api/products/:id/rate', newverifyToken, (req, res) => {
  const productId = req.params.id;
  const userId = req.user.id;
  const { rating, feedback_text } = req.body;

  if (rating < 1 || rating > 5) {
    return res.status(400).json({ message: "Rating must be between 1 and 5." });
  }

  // Insert the rating into the database
  const ratingQuery = 'INSERT INTO ratings (product_id, user_id, rating) VALUES (?, ?, ?)';
  db.query(ratingQuery, [productId, userId, rating], (ratingErr, ratingResult) => {
    if (ratingErr) {
      console.error('Error saving rating:', ratingErr);
      return res.status(500).json({ message: "Error saving rating." });
    }

    // If feedback is provided, insert it into the feedback table
    if (feedback_text) {
      const feedbackQuery = 'INSERT INTO feedback (product_id, user_id, feedback_text) VALUES (?, ?, ?)';
      db.query(feedbackQuery, [productId, userId, feedback_text], (feedbackErr, feedbackResult) => {
        if (feedbackErr) {
          console.error('Error saving feedback:', feedbackErr);
          return res.status(500).json({ message: "Error saving feedback." });
        }
        res.status(201).json({ message: "Rating and feedback added successfully." });
      });
    } else {
      res.status(201).json({ message: "Rating added successfully." });
    }
  });
});

// New route to get ratings and feedback for a product
app.get('/api/products/:id/ratings', (req, res) => {
  const productId = req.params.id;
  const query = `
    SELECT r.rating, f.feedback_text, u.fullName, u.profilePicture, r.created_at
    FROM ratings r
    LEFT JOIN feedback f ON r.product_id = f.product_id AND r.user_id = f.user_id
    JOIN users u ON r.user_id = u.id
    WHERE r.product_id = ?
    ORDER BY r.created_at DESC`;

  db.query(query, [productId], (err, results) => {
    if (err) {
      console.error('Error fetching ratings and feedback:', err);
      return res.status(500).json({ message: "Error fetching ratings and feedback." });
    }
    res.status(200).json(results);
  });
});

// New route to get average rating for a product
app.get('/api/products/:id/average-rating', (req, res) => {
  const productId = req.params.id;
  const query = `
    SELECT AVG(rating) as averageRating, COUNT(*) as totalRatings
    FROM ratings
    WHERE product_id = ?`;

  db.query(query, [productId], (err, results) => {
    if (err) {
      console.error('Error fetching average rating:', err);
      return res.status(500).json({ message: "Error fetching average rating." });
    }
    const { averageRating, totalRatings } = results[0];
    res.status(200).json({ 
      averageRating: averageRating ? parseFloat(averageRating).toFixed(1) : 0, 
      totalRatings 
    });
  });
});


// New route to add a comment
app.post('/api/products/:id/comments', newverifyToken, (req, res) => {
    const productId = req.params.id;
    const userId = req.user.id; // Get the user ID from the token
    const { text } = req.body; // Get the comment text from the request body

    // Insert the comment into the database
    const query = 'INSERT INTO comments (product_id, user_id, text) VALUES (?, ?, ?)';
    db.query(query, [productId, userId, text], (err, result) => {
        if (err) {
            console.error('Error saving comment:', err);
            return res.status(500).json({ message: "Error saving comment." });
        }
        res.status(201).json({ message: "Comment added successfully." });
    });
});

// New route to get comments for a product
app.get('/api/products/:id/comments', (req, res) => {
  const productId = req.params.id;
  const query = `
    SELECT c.id, c.text, c.created_at, u.fullName, u.profilePicture
    FROM comments c
    JOIN users u ON c.user_id = u.id
    WHERE c.product_id = ?
    ORDER BY c.created_at DESC`;

  db.query(query, [productId], (err, results) => {
    if (err) {
      console.error('Error fetching comments:', err);
      return res.status(500).json({ message: "Error fetching comments." });
    }
    res.status(200).json(results);
  });
});

app.get('/api/products/:id/user-rating', newverifyToken, (req, res) => {
  const productId = req.params.id;
  const userId = req.user.id;

  const query = 'SELECT rating FROM ratings WHERE product_id = ? AND user_id = ?';
  db.query(query, [productId, userId], (err, results) => {
    if (err) {
      console.error('Error fetching user rating:', err);
      return res.status(500).json({ message: "Error fetching user rating." });
    }
    const userRating = results.length > 0 ? results[0].rating : null;
    res.status(200).json({ userRating });
  });
});

// Add this route after your existing routes

// Route to handle booking form submissions
app.post('/api/bookings', newverifyToken, (req, res) => {
  const userId = req.user.id;
  const { 
    fullName, 
    eventDate, 
    contactNumber, 
    email, 
    venueName, 
    venueAddress, 
    expectedGuests, 
    specialRequests, 
    packageId,
    eventType
  } = req.body;

  const query = `
    INSERT INTO bookings 
    (user_id, full_name, event_date, contact_number, email, venue_name, venue_address, expected_guests, special_requests, package_id, event_type) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `;

  db.query(
    query, 
    [userId, fullName, eventDate, contactNumber, email, venueName, venueAddress, expectedGuests, specialRequests, packageId, eventType],
    (err, result) => {
      if (err) {
        console.error('Error saving booking:', err);
        return res.status(500).json({ message: "Error saving booking." });
      }
      res.status(201).json({ message: "Booking submitted successfully.", bookingId: result.insertId });
    }
  );
});

// Start the server
app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});