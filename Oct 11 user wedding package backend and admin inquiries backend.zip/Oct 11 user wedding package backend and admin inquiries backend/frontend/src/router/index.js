import { createRouter, createWebHistory } from "vue-router";
import HomePage from "../components/HomePage.vue";
import ContactUs from "../components/ContactUs.vue";
import Gallery from "../components/Gallery.vue";
import Packages from "../components/packages.vue";
import WeddingPackage from "../components/packages/WeddingPackage.vue";
import DebutPackage from "../components/packages/DebutPackage.vue";
import KiddiePartyPackage from "../components/packages/KiddiePartyPackage.vue";
import ChristeningPackage from "../components/packages/ChristeningPackage.vue";
import Login from '../components/login.vue';
import AdminDashboard from "../components/AdminDashboard.vue";
import AdminUsers from '@/components/AdminUsers.vue';
import AdminInquiries from '@/components/AdminInquiries.vue';
import AdminPackages from '@/components/AdminPackages.vue'; // Add this import
import AdminEvents from '@/components/AdminEvents.vue'; // Add this import

const routes = [
  {
    path: "/",
    name: "Home",
    component: HomePage,
    meta: { hideForLoggedIn: true }
  },
  {
    path: "/contact",
    name: "Contact",
    component: ContactUs,
    meta: { hideForAdmin: true, hideForLoggedIn: true } // Add this line
  },
  {
    path: "/gallery",
    name: "Gallery",
    component: Gallery,
  },
  {
    path: "/packages",
    component: Packages,
    children: [
      {
        path: "wedding",
        name: "WeddingPackage",
        component: WeddingPackage,
      },
      {
        path: "debut",
        name: "DebutPackage",
        component: DebutPackage,
      },
      {
        path: "kiddie-party",
        name: "KiddiePartyPackage",
        component: KiddiePartyPackage,
      },
      {
        path: "christening",
        name: "ChristeningPackage",
        component: ChristeningPackage,
      },
    ],
  },
  {
    path: '/login',
    name: 'Login',
    component: Login,
    meta: { hideForLoggedIn: true }
  },
  {
    path: '/admin',
    name: 'AdminDashboard',
    component: AdminDashboard,
    meta: { requiresAuth: true, requiresAdmin: true },
  },
  {
    path: '/admin/users',
    name: 'AdminUsers',
    component: AdminUsers,
    meta: { requiresAdmin: true },
  },
  {
    path: '/admin/inquiries', // Add this new route
    name: 'AdminInquiries',
    component: AdminInquiries,
    meta: { requiresAdmin: true },
  },
  {
    path: '/admin/packages', // Add this new route
    name: 'AdminPackages',
    component: AdminPackages,
    meta: { requiresAdmin: true },
  },
  {
    path: '/admin/events',
    name: 'AdminEvents',
    component: AdminEvents,
    meta: { requiresAdmin: true },
  },
  // Add this catch-all route at the end of your routes array
  {
    path: '/:pathMatch(.*)*',
    redirect: '/gallery'
  }
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

router.beforeEach((to, from, next) => {
  const token = localStorage.getItem('token');
  const userRole = localStorage.getItem('userRole');
  
  if (to.matched.some(record => record.meta.requiresAdmin)) {
    if (userRole !== 'admin') {
      next('/gallery');
    } else {
      next();
    }
  } else if (to.matched.some(record => record.meta.hideForAdmin) && userRole === 'admin') {
    next('/admin');
  } else if (to.matched.some(record => record.meta.hideForLoggedIn) && token) {
    next('/gallery');
  } else {
    next();
  }
});

export default router;
