<template>
  <section class="about-us">
    <div class="about-us-content">
      <h2>ABOUT US</h2>
      <div class="about-us-grid">
        <div class="about-us-text">
          <p>
            Razz Rel Events is your premier event planning partner, dedicated to
            creating unforgettable moments for every occasion. With our passion
            for perfection and attention to detail, we transform your visions
            into reality.
          </p>
          <p>
            From weddings to corporate gatherings, our experienced team ensures
            that every aspect of your event is meticulously planned and
            flawlessly executed.
          </p>
          <p>
            Let us take the stress out of event planning and make your special
            day truly extraordinary. With Razz Rel Events, your dream event is
            just a conversation away.
          </p>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup>
// Any necessary imports or logic
</script>
