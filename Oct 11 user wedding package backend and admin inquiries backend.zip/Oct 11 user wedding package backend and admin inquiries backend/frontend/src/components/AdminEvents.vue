<template>
  <div class="admin-events">
    <AdminSidebar :class="{ 'show-menu': showMenu }" />
    <main>
      <button @click="toggleMenu" class="menu-btn">
        <span class="material-icons-sharp">menu</span>
      </button>
      <h2>Manage Events</h2>
      <div class="insights">
        <div class="events">
          <span class="material-icons-sharp">event</span>
          <div class="middle">
            <div class="left">
              <h3>Total Events</h3>
              <h1>{{ events.length }}</h1>
            </div>
            <div class="progress">
              <svg>
                <circle cx="38" cy="38" r="36"></circle>
              </svg>
              <div class="number">
                <p>{{ Math.round((events.length / 100) * 100) }}%</p>
              </div>
            </div>
          </div>
          <small class="text-muted">All scheduled events</small>
        </div>
      </div>
      <div class="recent-events">
        <h2>Recent Events</h2>
        <table>
          <thead>
            <tr>
              <th>Event Name</th>
              <th>Date</th>
              <th>Status</th>
              <th>Guests</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="event in events" :key="event.id">
              <td>{{ event.name }}</td>
              <td>{{ event.date }}</td>
              <td :class="event.status.toLowerCase()">{{ event.status }}</td>
              <td>{{ event.guests }}</td>
              <td><button class="btn-details">Details</button></td>
            </tr>
          </tbody>
        </table>
        <a href="#" class="show-all">Show All</a>
      </div>
      <div class="add-event" @click="openAddEventModal">
        <span class="material-icons-sharp">add</span>
        <h3>Add Event</h3>
      </div>
    </main>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import AdminSidebar from './AdminSidebar.vue';

const events = ref([
  { id: 1, name: "Wedding Ceremony", date: "2023-06-15", status: "Upcoming", guests: 150 },
  { id: 2, name: "Corporate Gala", date: "2023-07-01", status: "Planning", guests: 200 },
  { id: 3, name: "Birthday Party", date: "2023-06-30", status: "Confirmed", guests: 50 },
  { id: 4, name: "Product Launch", date: "2023-08-10", status: "Pending", guests: 300 },
]);

const isAddEventModalOpen = ref(false);
const showMenu = ref(false);

const openAddEventModal = () => {
  isAddEventModalOpen.value = true;
};

const closeAddEventModal = () => {
  isAddEventModalOpen.value = false;
};

const toggleMenu = () => {
  showMenu.value = !showMenu.value;
};
</script>

<style scoped>
.admin-events {
  display: flex;
  height: 100vh;
  background-color: #f6f6f9;
}

main {
  flex: 1;
  padding: 2rem;
  overflow-y: auto;
}

.menu-btn {
  display: none;
  background: none;
  border: none;
  cursor: pointer;
  font-size: 1.5rem;
  color: #363949;
}

@media screen and (max-width: 768px) {
  .menu-btn {
    display: block;
  }

  .admin-events {
    position: relative;
  }

  .show-menu {
    display: block;
    position: absolute;
    left: 0;
    top: 0;
    width: 70%;
    height: 100vh;
    z-index: 100;
    background-color: white;
    box-shadow: 0 2rem 3rem rgba(132, 139, 200, 0.18);
  }
}

h2 {
  margin-bottom: 1rem;
  color: #363949;
}

.insights {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
  gap: 1.6rem;
  margin-bottom: 2rem;
}

.events {
  background: white;
  padding: 1.8rem;
  border-radius: 2rem;
  box-shadow: 0 2rem 3rem rgba(132, 139, 200, 0.18);
  transition: all 300ms ease;
}

.events:hover {
  box-shadow: none;
}

.events .material-icons-sharp {
  background: #7380ec;
  padding: 0.5rem;
  border-radius: 50%;
  color: white;
  font-size: 2rem;
}

.events .middle {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.events h3 {
  margin: 1rem 0 0.6rem;
  font-size: 1rem;
}

.events .progress {
  position: relative;
  width: 92px;
  height: 92px;
  border-radius: 50%;
}

.events svg {
  width: 7rem;
  height: 7rem;
}

.events svg circle {
  fill: none;
  stroke: #7380ec;
  stroke-width: 14;
  stroke-linecap: round;
  transform: translate(5px, 5px);
  stroke-dasharray: 110;
  stroke-dashoffset: 92;
}

.events .number {
  position: absolute;
  top: 0;
  left: 0;
  height: 100%;
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
}

.recent-events {
  margin-top: 2rem;
}

.recent-events table {
  background: white;
  width: 100%;
  border-radius: 2rem;
  padding: 1.8rem;
  text-align: center;
  box-shadow: 0 2rem 3rem rgba(132, 139, 200, 0.18);
  transition: all 300ms ease;
}

.recent-events table:hover {
  box-shadow: none;
}

.recent-events table th {
  padding: 0.8rem 0;
  color: #363949;
  font-weight: 600;
}

.recent-events table td {
  padding: 0.8rem 0;
  border-bottom: 1px solid rgba(132, 139, 200, 0.18);
  color: #677483;
}

.btn-details {
  background: #7380ec;
  color: white;
  padding: 0.4rem 0.8rem;
  border-radius: 0.4rem;
  border: none;
  cursor: pointer;
  transition: all 300ms ease;
}

.btn-details:hover {
  background: #5a67d8;
}

.show-all {
  display: block;
  text-align: center;
  margin: 1rem auto;
  color: #7380ec;
}

.add-event {
  background: white;
  border-radius: 2rem;
  padding: 1.8rem;
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-top: 2rem;
  box-shadow: 0 2rem 3rem rgba(132, 139, 200, 0.18);
  transition: all 300ms ease;
  cursor: pointer;
}

.add-event:hover {
  box-shadow: none;
}

.add-event .material-icons-sharp {
  background: #7380ec;
  padding: 0.5rem;
  border-radius: 50%;
  color: white;
  font-size: 2rem;
}

.upcoming { color: #41f1b6; }
.planning { color: #ffbb55; }
.confirmed { color: #7380ec; }
.pending { color: #ff7782; }
</style>