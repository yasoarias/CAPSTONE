<template>
  <header :class="{ 'dark-mode': isDarkMode }">
    <!-- Sidebar Toggle Button - only visible when user is logged in -->
    <button v-if="user" class="sidebar-toggle" @click="toggleSidebar">☰</button>
    
    <div class="content-container header-content">
      <div class="left-section">
        <!-- Logo -->
        <div :class="['logo-container', { 'logged-in': user }]">
          <router-link to="/">
            <img :src="logoPath" alt="Razz Rel Events Logo" class="logo" />
          </router-link>
        </div>
      </div>
      
      <nav>
        <router-link to="/" :class="{ 'active': isActive('/') }" v-if="!user && !isAdmin">Home</router-link>
        
        <!-- Packages Dropdown - only visible when no user is logged in -->
        <div v-if="!user" class="dropdown">
          <button class="dropbtn" @click="togglePackagesDropdown">
            Packages
            <i class="fa fa-caret-down"></i>
          </button>
          <div class="dropdown-content" v-show="isPackagesDropdownOpen">
            <router-link to="/packages/wedding" :class="{ 'active': isActive('/packages/wedding') }">Wedding</router-link>
            <router-link to="/packages/debut" :class="{ 'active': isActive('/packages/debut') }">Debut</router-link>
            <router-link to="/packages/kiddie-party" :class="{ 'active': isActive('/packages/kiddie-party') }">Kiddie Party</router-link>
            <router-link to="/packages/christening" :class="{ 'active': isActive('/packages/christening') }">Christening</router-link>
          </div>
        </div>
        
        <router-link to="/gallery" :class="{ 'active': isActive('/gallery') }" v-if="!user">Gallery</router-link>
        <router-link to="/contact" :class="{ 'active': isActive('/contact') }" v-if="!user && !isAdmin">Contact</router-link>
        <router-link v-if="isAdmin" to="/admin" :class="{ 'active': isActive('/admin') }">Admin Dashboard</router-link>
      </nav>
      
      <!-- User actions (dropdown, etc.) -->
      <div class="user-actions">
        <div class="user-dropdown" @click="toggleUserDropdown">
          <template v-if="user">
            <!-- Add heart and message icons for regular users -->
            <template v-if="!isAdmin">
              <i class="fas fa-heart action-icon"></i>
              <i class="fas fa-envelope action-icon"></i>
            </template>
            <img :src="userProfileImage" alt="User Profile" class="profile-image" @error="handleImageError" />
            <span class="user-name-display">{{ user.fullName }}</span>
          </template>
          <template v-else>
            <i class="fas fa-user user-icon"></i>
          </template>
          <div class="user-dropdown-content" v-show="isUserDropdownOpen">
            <span class="user-name">{{ user ? user.fullName : 'Guest' }}</span>
            <template v-if="user">
              <button @click="openSettingsModal" class="dropdown-item">Settings</button>
              <button @click="toggleDarkMode" class="dropdown-item mode-toggle">
                {{ isDarkMode ? "Light Mode ☀️" : "Dark Mode 🌙" }}
              </button>
              <button @click="handleLogout" class="dropdown-item">Logout</button>
            </template>
            <template v-else>
              <button @click="openLoginModal" class="dropdown-item">Login</button>
              <button @click="openRegisterModal" class="dropdown-item">Register</button>
              <button @click="toggleDarkMode" class="dropdown-item mode-toggle">
                {{ isDarkMode ? "Light Mode ☀️" : "Dark Mode 🌙" }}
              </button>
            </template>
          </div>
        </div>
      </div>
    </div>
  </header>

  <!-- Sidebar - only rendered when user is logged in -->
  <div v-if="user" class="sidebar" :class="{ 'open': isSidebarOpen }">
    <div class="sidebar-content">
      <h2 class="sidebar-title">Menu</h2>
      <nav class="sidebar-nav">
        <router-link to="/packages/wedding" :class="{ 'active': isActive('/packages/wedding') }">Wedding</router-link>
        <router-link to="/packages/debut" :class="{ 'active': isActive('/packages/debut') }">Debut</router-link>
        <router-link to="/packages/kiddie-party" :class="{ 'active': isActive('/packages/kiddie-party') }">Kiddie Party</router-link>
        <router-link to="/packages/christening" :class="{ 'active': isActive('/packages/christening') }">Christening</router-link>
        <router-link to="/gallery" :class="{ 'active': isActive('/gallery') }">Gallery</router-link>
      </nav>
    </div>
    <button class="close-btn" @click="toggleSidebar">&times;</button>
  </div>

  <SettingsModal v-if="showSettingsModal" @close="closeSettingsModal" :user="user" :token="token" @update-user="updateUser" />
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted, watch } from "vue";
import logoImage from "@/assets/logo.png";
import defaultProfileImage from '@/assets/default-profile.png'; // Update this path to where your default profile image is stored
import { useRoute, useRouter } from 'vue-router';
import SettingsModal from "./SettingsModal.vue";

const logoPath = ref(logoImage);
const isDarkMode = ref(false);
const isDropdownOpen = ref(false);
const isUserDropdownOpen = ref(false);
const isPackagesDropdownOpen = ref(false);
const isSidebarOpen = ref(false); // Sidebar state
const user = ref(null);
const showSettingsModal = ref(false);
const token = ref(localStorage.getItem('token'));

// Compute whether the user is an admin
const isAdmin = computed(() => user.value && user.value.role === 'admin');

// Watch for changes in the user object
watch(user, (newUser) => {
  if (newUser) {
    console.log('Current user role:', newUser.role);
  } else {
    console.log('No user logged in');
  }
}, { immediate: true });

const toggleDarkMode = () => {
  isDarkMode.value = !isDarkMode.value;
  document.body.classList.toggle("dark-mode", isDarkMode.value);
};

const toggleDropdown = () => {
  isDropdownOpen.value = !isDropdownOpen.value;
};

const closeDropdown = (event) => {
  if (!event.target.closest(".dropdown")) {
    isDropdownOpen.value = false;
  }
};

const toggleUserDropdown = () => {
  if (isUserDropdownOpen.value) {
    forceCloseUserDropdown();
  } else {
    isUserDropdownOpen.value = true;
  }
};

const closeUserDropdown = (event) => {
  if (!event.target.closest(".user-dropdown")) {
    isUserDropdownOpen.value = false;
  }
};

const openLoginModal = () => {
  emit('openLoginModal');
  isUserDropdownOpen.value = false;
};

const openRegisterModal = () => {
  emit('openRegisterModal');
  isUserDropdownOpen.value = false;
};

const handleLogout = () => {
  localStorage.removeItem('token');
  localStorage.removeItem('userRole'); // Add this line to remove the userRole
  user.value = null;
  emit('logout');
  router.push('/'); // Navigate to home page after logout
};


const openSettingsModal = () => {
  showSettingsModal.value = true;
  forceCloseUserDropdown();
};

const closeSettingsModal = () => {
  showSettingsModal.value = false;
};

const updateUser = (updatedUser) => {
  console.log('Updating user with:', updatedUser);
  user.value = { ...user.value, ...updatedUser };
  console.log('User value after update:', user.value);
  // Fetch the latest user data from the server
  fetchUserInfo();
};


const router = useRouter();

const fetchUserInfo = async () => {
  try {
    if (!token.value) {
      console.error('No token found');
      return;
    }

    console.log('Fetching user info with token:', token.value);

    const response = await fetch('http://localhost:3000/user/profile', {
      headers: {
        'Authorization': token.value,
      },
    });

    console.log('User profile response status:', response.status);

    if (response.ok) {
      const userData = await response.json();
      console.log('Raw user data from server:', userData);
      user.value = {
        ...userData,
        profilePicture: userData.profilePicture || defaultProfileImage
      };
      console.log('Updated user.value:', user.value);
    } else {
      console.error('Failed to fetch user data');
      localStorage.removeItem('token');
      localStorage.removeItem('userRole');
      token.value = null;
    }
  } catch (error) {
    console.error('Error fetching user info:', error);
  }
};


onMounted(() => {
  document.addEventListener("click", closeDropdown);
  document.addEventListener("click", closeUserDropdown);
  document.addEventListener("click", closePackagesDropdown);
  if (token.value) {
    fetchUserInfo();
  }
});

onUnmounted(() => {
  document.removeEventListener("click", closeDropdown);
  document.removeEventListener("click", closeUserDropdown);
  document.removeEventListener("click", closePackagesDropdown);
});

// Define emits
const emit = defineEmits(['openLoginModal', 'openRegisterModal', 'logout']);

const route = useRoute();

const isActive = (path) => {
  return route.path === path;
};

const isPackageActive = () => {
  return route.path.startsWith('/packages');
};


const userProfileImage = computed(() => {
  console.log('User value:', user.value);
  console.log('Default profile image:', defaultProfileImage);
  
  if (user.value && user.value.profilePicture) {
    const profilePicture = user.value.profilePicture.startsWith('http') 
      ? user.value.profilePicture 
      : `http://localhost:3000${user.value.profilePicture}`;
    console.log('Returning profile picture:', profilePicture);
    return profilePicture;
  }
  console.log('Returning default profile image');
  return defaultProfileImage;
});


const props = defineProps(['user', 'token']);

const handleImageError = (e) => {
  console.error('Error loading image:', e);
  e.target.src = defaultProfileImage;
};

const forceCloseUserDropdown = () => {
  isUserDropdownOpen.value = false;
};

// Toggle sidebar
const toggleSidebar = () => {
  isSidebarOpen.value = !isSidebarOpen.value;
};

const togglePackagesDropdown = () => {
  isPackagesDropdownOpen.value = !isPackagesDropdownOpen.value;
};

// Close packages dropdown when clicking outside
const closePackagesDropdown = (event) => {
  if (!event.target.closest('.dropdown')) {
    isPackagesDropdownOpen.value = false;
  }
};
</script>

<style lang="scss" scoped>
/* Sidebar styles */
.sidebar {
  position: fixed;
  top: 0;
  left: -250px;
  width: 250px;
  height: 100%;
  background-color: #2c3e50;
  color: white;
  transition: left 0.3s ease;
  z-index: 1000;
  box-shadow: 2px 0 10px rgba(0,0,0,0.1);

  &.open {
    left: 0;
  }

  .sidebar-content {
    padding: 20px;
    height: 100%;
    display: flex;
    flex-direction: column;
  }

  .close-btn {
    position: absolute;
    top: 10px;
    right: 10px;
    background: none;
    border: none;
    color: white;
    font-size: 24px;
    cursor: pointer;
    transition: color 0.3s ease;

    &:hover {
      color: #ff6347;
    }
  }

  .sidebar-title {
    font-size: 20px;
    margin-bottom: 20px;
    padding-bottom: 10px;
    border-bottom: 1px solid rgba(255,255,255,0.1);
    text-align: left;
    color: #ecf0f1;
  }

  .sidebar-nav {
    display: flex;
    flex-direction: column;

    a {
      color: #ecf0f1;
      text-decoration: none;
      padding: 12px 15px;
      transition: all 0.3s ease;
      font-size: 16px;
      text-align: left;
      border-radius: 4px;

      &:hover {
        background-color: rgba(255,255,255,0.1);
      }

      &.active {
        background-color: #ff6347;
        color: white;
      }
    }
  }
}

/* Header styles */
.header-content {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 20px;
  padding-left: 50px; // Add some padding to account for the sidebar toggle
}

.left-section {
  display: flex;
  align-items: center;
}

.sidebar-toggle {
  position: fixed;
  top: 10px;
  left: 10px;
  background: none;
  border: none;
  color: #333;
  font-size: 24px;
  cursor: pointer;
  padding: 10px;
  z-index: 1001; // Ensure it's above other elements
}

.dark-mode {
  .sidebar-toggle {
    color: white;
  }
}

.logo-container {
  display: flex;
  align-items: center;
  height: 100%;

  &.logged-in {
    margin-left: 10px; /* Adjust as needed for spacing */
  }
}

.logo {
  height: 100px; /* Adjust as needed */
  object-fit: contain;
  width: 250px;
}

nav {
  display: flex;
  align-items: center;

  a {
    color: #333;
    text-decoration: none;
    padding: 0.5rem 1rem;
    transition: background-color 0.3s ease;
    border-radius: 12px;

    &:hover {
      background-color: #ff6347;
      color: white;
    }

    &.active {
      color: #ff6347;
      font-weight: bold;
    }
  }
}

.user-actions {
  display: flex;
  align-items: center;
  position: relative; // Add this
}

.user-icon {
  font-size: 24px;
  color: #333;
  cursor: pointer;
}

.dark-mode {
  .user-icon {
    color: white;
  }
}

.user-dropdown {
  display: flex;
  align-items: center;
  cursor: pointer;
  position: relative; // Add this
}

.user-dropdown-content {
  position: absolute;
  right: 0;
  top: 100%; // Change this from 'top: 100%'
  background-color: white;
  min-width: 200px;
  box-shadow: 0 2px 10px rgba(0,0,0,0.3);
  border-radius: 8px;
  overflow: hidden;
  z-index: 1000;
}

.dropdown-item {
  color: #333;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
  cursor: pointer;
  border: none;
  background: none;
  width: 100%;
  font-size: 14px;

  &:hover {
    background-color: #444;
    color: white;
  }
}

.mode-toggle {
  margin: 8px 0;
  border-radius: 4px;

  &:hover {
    background-color: #555;
    color: white;
  }
}

.user-name {
  padding: 12px 16px;
  display: block;
  font-weight: bold;
  color: #333;
  border-bottom: 1px solid #444;
}

.dark-mode {
  span {
    color: white;
  }

  .user-icon {
    filter: brightness(0) invert(1);
  }

  .user-dropdown-content {
    background-color: #333;
    color: white;
  }

  .dropdown-item {
    color: white;

    &:hover {
      background-color: #444;
      border-radius: 12px;
    }
  }

  .user-name,
  .dark-mode-toggle {
    border-color: #555;
  }
}

.user-name-display {
  font-size: 0.9rem;
  font-weight: bold;
}

.profile-image {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  object-fit: cover;
  margin-right: 10px;
}

/* Dropdown styles */
.dropdown {
  position: relative;
  display: inline-block;
}

.dropbtn {
  background-color: transparent;
  color: #333;
  padding: 0.5rem 1rem;
  font-size: 16px;
  border: none;
  cursor: pointer;

  &.active {
    color: #ff6347;
    font-weight: bold;
  }
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;

  a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;

    &:hover {
      background-color: #f1f1f1;
    }
  }
}

.dropdown:hover .dropdown-content {
  display: block;
}

.dark-mode {
  .dropbtn {
    color: white;
  }

  .dropdown-content {
    background-color: #333;

    a {
      color: white;

      &:hover {
        background-color: #444;
      }
    }
  }

  nav {
    a.active,
    .dropbtn.active {
      color: #ff9980;
    }

    a:hover,
    a.active:hover,
    .dropbtn.active:hover {
      background-color: #ff9980;
      color: #333;
    }
  }

  .dropdown-content {
    a.active {
      background-color: #555;
      color: #ff9980;
    }

    a:hover,
    a.active:hover {
      background-color: #ff9980;
      color: #333;
    }
  }
}

/* Media query for mobile responsiveness */
@media (max-width: 768px) {
  .header-content {
    flex-wrap: wrap;
    padding: 10px;
    padding-left: 40px; // Adjust padding for mobile
  }

  .left-section {
    width: 100%;
    justify-content: space-between;
    margin-bottom: 10px;
  }

  .logo-container {
    flex-grow: 1;
    text-align: center;
  }

  .logo {
    height: 60px; /* Smaller logo for mobile */
    width: auto;
  }

  .sidebar-toggle {
    top: 5px;
    left: 5px;
    font-size: 20px;
    padding: 5px;
  }

  nav {
    width: 100%;
    justify-content: center;
    margin-bottom: 10px;

    a, .dropdown {
      padding: 8px 12px;
      margin: 2px;
      font-size: 14px;
    }
  }

  .dropdown-content {
    position: static;
    display: none;
    width: 100%;
    box-shadow: none;
    margin-top: 5px;

    &.show {
      display: block;
    }
  }

  .user-actions {
    width: 100%;
    justify-content: center;
    position: relative; // Add this
  }

  .user-dropdown {
    width: auto; // Change this from 'width: 100%'
    text-align: center;
  }

  .user-dropdown-content {
    width: 200px; // Set a fixed width
    position: absolute; // Change this from 'position: static'
    right: 0; // Align to the right
    top: 100%; // Position below the user icon
    box-shadow: 0 2px 10px rgba(0,0,0,0.3); // Add shadow back for mobile
  }

  .profile-image {
    width: 30px;
    height: 30px;
  }

  .user-name-display {
    font-size: 14px;
  }
}

.user-actions {
  display: flex;
  align-items: center;
  position: relative;
}

.user-dropdown {
  display: flex;
  align-items: center;
  cursor: pointer;
  position: relative;
}

.action-icon {
  font-size: 24px; // Increased from 18px
  color: #333;
  margin-right: 15px; // Increased from 10px for more spacing
  cursor: pointer;
  transition: color 0.3s ease;

  &:hover {
    color: #ff6347;
  }
}

.dark-mode {
  .action-icon {
    color: white;

    &:hover {
      color: #ff9980;
    }
  }
}

.profile-image {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  object-fit: cover;
  margin-right: 10px;
}

@media (max-width: 768px) {
  .action-icon {
    font-size: 20px; // Increased from 16px for mobile
    margin-right: 12px; // Adjusted spacing for mobile
  }

  .profile-image {
    width: 30px;
    height: 30px;
  }
}
</style>