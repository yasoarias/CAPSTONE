<template>
  <div class="admin-packages">
    <AdminSidebar :class="{ 'show-menu': showMenu }" />
    <main>
      <button @click="toggleMenu" class="menu-btn">
        <span class="material-icons-sharp">menu</span>
      </button>
      <h2>Manage Packages</h2>
      <div class="insights">
        <div class="packages">
          <span class="material-icons-sharp">inventory</span>
          <div class="middle">
            <div class="left">
              <h3>Total Packages</h3>
              <h1>{{ packages.length }}</h1>
            </div>
            <div class="progress">
              <svg>
                <circle cx="38" cy="38" r="36"></circle>
              </svg>
              <div class="number">
                <p>{{ Math.round((packages.length / 100) * 100) }}%</p>
              </div>
            </div>
          </div>
          <small class="text-muted">All available packages</small>
        </div>
      </div>
      <div class="recent-packages">
        <h2>Recent Packages</h2>
        <div class="package-grid">
          <div v-for="pkg in paginatedPackages" :key="pkg.id" class="package-card">
            <img 
              :src="pkg.image" 
              :alt="pkg.name" 
              class="package-image"
              @error="handleImageError"
            >
            <h3>{{ pkg.name }}</h3>
            <p>Category: {{ pkg.category }}</p>
            <p>Price: ₱{{ pkg.price ? pkg.price.toLocaleString() : 'N/A' }}</p>
            <p :class="pkg.status ? pkg.status.toLowerCase() : ''">
              Status: {{ pkg.status || 'N/A' }}
            </p>
            <button class="btn-details">Details</button>
          </div>
        </div>
        <div class="pagination">
          <button @click="prevPage" :disabled="currentPage === 1">&lt; Prev</button>
          <span>Page {{ currentPage }} of {{ totalPages }}</span>
          <button @click="nextPage" :disabled="currentPage === totalPages">Next &gt;</button>
        </div>
      </div>
      <div class="add-package" @click="openAddPackageModal">
        <span class="material-icons-sharp">add</span>
        <h3>Add Package</h3>
      </div>
    </main>
    <AddPackageModal :isOpen="isAddPackageModalOpen" @close="closeAddPackageModal" />
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue';
import AdminSidebar from './AdminSidebar.vue';
import AddPackageModal from './AddPackageModal.vue';

const packages = ref([]);
const isAddPackageModalOpen = ref(false);
const showMenu = ref(false);
const currentPage = ref(1);
const itemsPerPage = 4;

const totalPages = computed(() => Math.ceil(packages.value.length / itemsPerPage));

const paginatedPackages = computed(() => {
  const start = (currentPage.value - 1) * itemsPerPage;
  const end = start + itemsPerPage;
  return packages.value.slice(start, end);
});

const toggleMenu = () => {
  showMenu.value = !showMenu.value;
};

const openAddPackageModal = () => {
  isAddPackageModalOpen.value = true;
};

const closeAddPackageModal = () => {
  isAddPackageModalOpen.value = false;
};

const prevPage = () => {
  if (currentPage.value > 1) {
    currentPage.value--;
  }
};

const nextPage = () => {
  if (currentPage.value < totalPages.value) {
    currentPage.value++;
  }
};

const fetchPackages = async () => {
  try {
    const response = await fetch('http://localhost:3000/api/products');
    const data = await response.json();
    packages.value = data.map(pkg => ({
      ...pkg,
      status: pkg.status || 'N/A',
      image: pkg.image_path ? `http://localhost:3000${pkg.image_path}` : 'https://via.placeholder.com/150'
    }));
  } catch (error) {
    console.error('Error fetching packages:', error);
  }
};

onMounted(async () => {
  await fetchPackages();
});

const handleImageError = (event) => {
  event.target.src = 'https://via.placeholder.com/150';
};
</script>

<style scoped>
.admin-packages {
  display: flex;
  height: 100vh;
  background-color: #f6f6f9;
}

main {
  flex: 1;
  padding: 2rem;
  overflow-y: auto;
}

h2 {
  margin-bottom: 1rem;
  color: #363949;
}

.insights {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
  gap: 1.6rem;
  margin-bottom: 2rem;
}

.packages {
  background: white;
  padding: 1.8rem;
  border-radius: 2rem;
  box-shadow: 0 2rem 3rem rgba(132, 139, 200, 0.18);
  transition: all 300ms ease;
}

.packages:hover {
  box-shadow: none;
}

.packages .material-icons-sharp {
  background: #7380ec;
  padding: 0.5rem;
  border-radius: 50%;
  color: white;
  font-size: 2rem;
}

.packages .middle {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.packages h3 {
  margin: 1rem 0 0.6rem;
  font-size: 1rem;
}

.packages .progress {
  position: relative;
  width: 92px;
  height: 92px;
  border-radius: 50%;
}

.packages svg {
  width: 7rem;
  height: 7rem;
}

.packages svg circle {
  fill: none;
  stroke: #7380ec;
  stroke-width: 14;
  stroke-linecap: round;
  transform: translate(5px, 5px);
  stroke-dasharray: 110;
  stroke-dashoffset: 92;
}

.packages .number {
  position: absolute;
  top: 0;
  left: 0;
  height: 100%;
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
}

.recent-packages {
  margin-top: 2rem;
}

.recent-packages table {
  background: white;
  width: 100%;
  border-radius: 2rem;
  padding: 1.8rem;
  text-align: center;
  box-shadow: 0 2rem 3rem rgba(132, 139, 200, 0.18);
  transition: all 300ms ease;
}

.recent-packages table:hover {
  box-shadow: none;
}

.recent-packages table th {
  padding: 0.8rem 0;
  color: #363949;
  font-weight: 600;
}

.recent-packages table td {
  padding: 0.8rem 0;
  border-bottom: 1px solid rgba(132, 139, 200, 0.18);
  color: #677483;
}

.btn-details {
  background: #7380ec;
  color: white;
  padding: 0.4rem 0.8rem;
  border-radius: 0.4rem;
  border: none;
  cursor: pointer;
  transition: all 300ms ease;
}

.btn-details:hover {
  background: #5a67d8;
}

.show-all {
  display: block;
  text-align: center;
  margin: 1rem auto;
  color: #7380ec;
}

.add-package {
  background: white;
  border-radius: 2rem;
  padding: 1.8rem;
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-top: 2rem;
  box-shadow: 0 2rem 3rem rgba(132, 139, 200, 0.18);
  transition: all 300ms ease;
  cursor: pointer;
}

.add-package:hover {
  box-shadow: none;
}

.add-package .material-icons-sharp {
  background: #7380ec;
  padding: 0.5rem;
  border-radius: 50%;
  color: white;
  font-size: 2rem;
}

@media screen and (max-width: 768px) {
  .menu-btn {
    display: inline-block;
    background: none;
    border: none;
    cursor: pointer;
    font-size: 1.5rem;
    color: #363949;
  }

  .admin-packages {
    position: relative;
  }

  .show-menu {
    display: block;
    position: absolute;
    left: 0;
    top: 0;
    width: 70%;
    height: 100vh;
    z-index: 100;
    background-color: white;
    box-shadow: 0 2rem 3rem rgba(132, 139, 200, 0.18);
  }
}

/* Override global sidebar styles */
:deep(aside .sidebar a) {
  border-left: none !important;
}

:deep(aside .sidebar a.active),
:deep(aside .sidebar a.active:before) {
  border-left: none !important;
  background-color: var(--color-light);
}

:deep(aside .sidebar a.active span) {
  color: var(--color-primary);
  margin-left: 0;
}

:deep(aside .sidebar a:hover) {
  color: var(--color-primary);
  background-color: var(--color-light);
  border-left: none !important;
}

:deep(aside .sidebar a:hover span) {
  margin-left: 0;
}

/* Additional styles to ensure consistency */
:deep(aside .sidebar) {
  background-color: white;
}

:deep(aside .sidebar a) {
  color: var(--color-info-dark);
  transition: all 300ms ease;
}

/* End of new styles */

/* Existing media query styles... */

.package-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
  gap: 1.5rem;
  margin-bottom: 1rem;
}

.package-card {
  background: white;
  border-radius: 1rem;
  padding: 1.5rem;
  box-shadow: 0 1rem 2rem rgba(132, 139, 200, 0.18);
  transition: all 300ms ease;
}

.package-card:hover {
  box-shadow: none;
}

.package-image {
  width: 100%;
  height: 200px; /* Adjust this value as needed */
  object-fit: cover;
  border-radius: 0.5rem;
  margin-bottom: 1rem;
}

.pagination {
  display: flex;
  justify-content: center;
  align-items: center;
  margin-top: 1rem;
}

.pagination button {
  background: #7380ec;
  color: white;
  border: none;
  padding: 0.5rem 1rem;
  border-radius: 0.4rem;
  cursor: pointer;
  transition: all 300ms ease;
}

.pagination button:hover:not(:disabled) {
  background: #5a67d8;
}

.pagination button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.pagination span {
  margin: 0 1rem;
}

/* ... rest of your existing styles ... */
</style>