<template>
  <div class="admin-dashboard">
    <AdminSidebar :class="{ 'show-menu': showMenu }" />
    <main>
      <button @click="toggleMenu" class="menu-btn">
        <span class="material-icons-sharp">menu</span>
      </button>
      <p>Dashboard</p>
      <div class="date">
        <input type="date" />
      </div>
      <div class="insights">
        <div class="sales">
          <span class="material-icons-sharp">group</span>
          <div class="middle">
            <div class="left">
              <h3>Total Users</h3>
              <h1>{{ userCount }}</h1>
            </div>
            <div class="progress">
              <svg>
                <circle cx="38" cy="38" r="36"></circle>
              </svg>
              <div class="number">
                <p>{{ Math.round((userCount / 100) * 100) }}%</p>
              </div>
            </div>
          </div>
          <small class="text-muted">Total registered users</small>
        </div>
        <div class="expenses">
          <span class="material-icons-sharp">bar_chart</span>
          <div class="middle">
            <div class="left">
              <h3>Total Requests</h3>
              <h1>50</h1>
            </div>
            <div class="progress">
              <svg>
                <circle cx="38" cy="38" r="36"></circle>
              </svg>
              <div class="number">
                <p>59%</p>
              </div>
            </div>
          </div>
          <small class="text-muted">Last 24 hours</small>
        </div>
        <div class="income">
          <span class="material-icons-sharp">stacked_line_chart</span>
          <div class="middle">
            <div class="left">
              <h3>Pending Reservation</h3>
              <h1>54</h1>
            </div>
            <div class="progress">
              <svg>
                <circle cx="38" cy="38" r="36"></circle>
              </svg>
              <div class="number">
                <p>44%</p>
              </div>
            </div>
          </div>
          <small class="text-muted">Last 24 hours</small>
        </div>
      </div>
      <div class="recent-orders">
        <h2>Notifications</h2>
        <table>
          <thead>
            <tr>
              <th>Event</th>
              <th>Client</th>
              <th>Date</th>
              <th>Guests</th>
              <th>Status</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="booking in recentBookings" :key="booking.id">
              <td>{{ booking.eventName }}</td>
              <td>{{ booking.clientName }}</td>
              <td>{{ booking.date }}</td>
              <td>{{ booking.guests }}</td>
              <td :class="booking.status.toLowerCase()">{{ booking.status }}</td>
              <td class="primary">Details</td>
            </tr>
          </tbody>
        </table>
        <a href="#">Show All</a>
      </div>
    </main>
    <div class="right">
      <div class="top">
        <button id="menu-btn">
          <span class="material-icons-sharp">menu</span>
        </button>
        <div class="theme-toggler">
          <span class="material-icons-sharp active">light_mode</span>
          <span class="material-icons-sharp">dark_mode</span>
        </div>
        <div class="profile">
          <div class="profile-photo">
            <img src="@/assets/profile-1.jpg" alt="Profile">
          </div>
        </div>
      </div>
      <div class="recent-updates">
        <h2>Users Updates</h2>
        <div class="updates">
          <div class="update" v-for="update in recentUpdates" :key="update.id">
            <div class="profile-photo">
              <img :src="update.image" :alt="update.name" @error="update.image = defaultProfileImage">
            </div>
            <div class="message">
              <p><strong>{{ update.name }}</strong> {{ update.message }}</p>
              <small class="text-muted">{{ update.time }}</small>
            </div>
          </div>
        </div>
        <div class="pagination">
          <button @click="prevPage" :disabled="currentPage === 1" class="pagination-button">Previous</button>
          <span>Page {{ currentPage }} of {{ totalPages }}</span>
          <button @click="nextPage" :disabled="currentPage === totalPages" class="pagination-button">Next</button>
        </div>
      </div>
      <div class="sales-analytics">
        <h2>Activities</h2>
        <div class="item online">
          <div class="icon">
            <span class="material-icons-sharp">shopping_cart</span>
          </div>
          <div class="right">
            <div class="info">
              <h3>Recent Added Packages</h3>
              <small class="text-muted">Last 24 hours</small>
            </div>
            <h5 class="success">+39%</h5>
            <h3>3849</h3>
          </div>
        </div>
        <div class="item offline">
          <div class="icon">
            <span class="material-icons-sharp">local_mall</span>
          </div>
          <div class="right">
            <div class="info">
              <h3>OFFLINE ORDERS</h3>
              <small class="text-muted">Last 24 hours</small>
            </div>
            <h5 class="danger">-17%</h5>
            <h3>1100</h3>
          </div>
        </div>
        <div class="item customers">
          <div class="icon">
            <span class="material-icons-sharp">person</span>
          </div>
          <div class="right">
            <div class="info">
              <h3>NEW CUSTOMERS</h3>
              <small class="text-muted">Last 24 hours</small>
            </div>
            <h5 class="success">+25%</h5>
            <h3>849</h3>
          </div>
        </div>
        <div class="item add-product" @click="openAddProductModal">
          <div>
            <span class="material-icons-sharp">add</span>
            <h3>Add Product</h3>
          </div>
        </div>
      </div>
    </div>
    <!-- Add this line to include the modal -->
    <AddProductModal :isOpen="isAddProductModalOpen" @close="closeAddProductModal" />
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { useRouter } from 'vue-router';
import AdminSidebar from './AdminSidebar.vue';
import AddProductModal from './AddProductModal.vue';
import defaultProfileImage from '@/assets/default-profile.png'; // Import the default image

const router = useRouter();
const userCount = ref(0);
const recentUpdates = ref([]);
const isAddProductModalOpen = ref(false);
const currentPage = ref(1);
const usersPerPage = 3; // Changed to 3 users per page
const totalPages = ref(1);
const showMenu = ref(false);

const fetchUsers = async (page = 1) => {
  try {
    const token = localStorage.getItem('token');
    const response = await fetch(`http://localhost:3000/api/users?page=${page}&limit=${usersPerPage}`, {
      headers: {
        'Authorization': token
      }
    });
    if (!response.ok) {
      throw new Error(`Failed to fetch users: ${response.status}`);
    }
    const data = await response.json();
    
    userCount.value = data.total;
    totalPages.value = Math.ceil(data.total / usersPerPage);
    recentUpdates.value = data.users.map((user) => ({
      id: user.id,
      name: user.fullName,
      image: user.profilePicture 
        ? `http://localhost:3000${user.profilePicture}`
        : defaultProfileImage, // Use imported default image
      message: `is a ${user.role} on our platform.`,
      time: new Date(user.createdAt).toLocaleDateString()
    }));
  } catch (error) {
    console.error('Error fetching users:', error);
    userCount.value = 0;
    recentUpdates.value = [];
  }
};

const nextPage = () => {
  if (currentPage.value < totalPages.value) {
    currentPage.value++;
    fetchUsers(currentPage.value);
  }
};

const prevPage = () => {
  if (currentPage.value > 1) {
    currentPage.value--;
    fetchUsers(currentPage.value);
  }
};

const toggleMenu = () => {
  showMenu.value = !showMenu.value;
};

onMounted(() => {
  fetchUsers();
});

// ... rest of your script
</script>

<style scoped>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap');

.admin-dashboard {
  display: grid;
  grid-template-columns: 240px 1fr;
  height: 100vh;
  overflow: hidden;
  font-family: 'Poppins', sans-serif;
}

aside {
  background-color: var(--color-white);
  padding: 1rem;
  overflow-y: auto;
}

main {
  overflow-y: auto;
  padding: 1.5rem;
  background-color: var(--color-background);
}

.insights {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
  gap: 1.5rem;
  margin-bottom: 2rem;
}

.insights > div {
  background-color: var(--color-white);
  padding: var(--card-padding);
  border-radius: var(--card-border-radius);
  box-shadow: var(--box-shadow);
  transition: all 300ms ease;
}

.recent-orders {
  margin-top: 2rem;
}

.recent-orders table {
  width: 100%;
  border-collapse: collapse;
}

.recent-orders table th,
.recent-orders table td {
  padding: 0.8rem;
  text-align: left;
}

.right {
  display: none;
}

/* Responsive adjustments */
@media screen and (max-width: 1200px) {
  .admin-dashboard {
    grid-template-columns: 1fr;
  }

  aside {
    position: fixed;
    left: -100%;
    background: var(--color-white);
    width: 18rem;
    z-index: 3;
    box-shadow: 1rem 3rem 4rem var(--color-light);
    height: 100vh;
    padding-right: var(--card-padding);
    transition: all 300ms ease;
  }

  aside.show-menu {
    left: 0;
  }

  main {
    margin-top: 8rem;
    padding: 0 1rem;
  }

  .right {
    width: 94%;
    margin: 0 auto 4rem;
  }
}

@media screen and (max-width: 768px) {
  .insights {
    grid-template-columns: 1fr;
    gap: 0;
  }

  .recent-orders {
    width: 100%;
    position: relative;
    margin: 3rem 0 0 0;
    box-shadow: none;
  }

  .recent-orders table {
    width: 100%;
    margin: 0;
  }

  .right {
    width: 100%;
    margin: 0;
  }

  .right .top {
    position: fixed;
    top: 0;
    left: 0;
    align-items: center;
    padding: 0 0.8rem;
    height: 4.6rem;
    background: var(--color-white);
    width: 100%;
    margin: 0;
    z-index: 2;
    box-shadow: 0 1rem 1rem var(--color-light);
  }

  .right .profile .info {
    display: none;
  }
}

/* Add this to toggle the sidebar on mobile */
.menu-btn {
  display: none;
}

@media screen and (max-width: 1200px) {
  .menu-btn {
    display: inline-block;
    background: transparent;
    cursor: pointer;
  }
}

.sales-analytics {
  margin-top: 1.5rem;
}

.content-wrapper {
  flex: 1;
  overflow-y: auto;
  padding: 2rem;
}

.main-content {
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  padding: 2rem;
}

h1 {
  margin-bottom: 2rem;
  color: #202124;
  font-size: 2rem;
}

.summary-cards {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1.5rem;
  margin-bottom: 2rem;
}

.card {
  background-color: #ffffff;
  border-radius: 8px;
  padding: 1.5rem;
  text-align: center;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
  transition: transform 0.3s ease;
}

.card:hover {
  transform: translateY(-5px);
}

.card h2 {
  margin-bottom: 0.5rem;
  color: #5f6368;
  font-size: 1.2rem;
}

.card p {
  font-size: 2rem;
  font-weight: bold;
  color: #1a73e8;
}

.charts {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
  gap: 2rem;
}

.chart {
  background-color: #ffffff;
  border-radius: 8px;
  padding: 1.5rem;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

.chart h2 {
  margin-bottom: 1rem;
  color: #202124;
  font-size: 1.5rem;
}

.item.add-product {
  cursor: pointer;
}

.item.add-product:hover {
  background-color: #f0f0f0;
}

.profile-photo img {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  object-fit: cover;
}

.pagination {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 20px;
}

.pagination-button {
  padding: 5px 10px;
  background-color: #4CAF50;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

.pagination-button:disabled {
  background-color: #cccccc;
  cursor: not-allowed;
}

.pagination-button:hover:not(:disabled) {
  background-color: #45a049;
}
</style>