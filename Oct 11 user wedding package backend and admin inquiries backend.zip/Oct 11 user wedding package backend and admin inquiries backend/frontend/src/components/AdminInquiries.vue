<template>
  <div class="admin-dashboard">
    <AdminSidebar />
    <main>
      <div class="insights">
        <div class="bookings">
          <span class="material-icons-sharp">event</span>
          <div class="middle">
            <div class="left">
              <h3>Total Bookings</h3>
              <h1>{{ bookings.length }}</h1>
            </div>
            <div class="progress">
              <svg>
                <circle cx="38" cy="38" r="36"></circle>
              </svg>
              <div class="number">
                <p>{{ Math.round((bookings.length / 100) * 100) }}%</p>
              </div>
            </div>
          </div>
          <small class="text-muted">Total received bookings</small>
        </div>
      </div>
      <div class="recent-bookings">
        <h2>Recent Bookings</h2>
        <table>
          <thead>
            <tr>
              <th>Full Name</th>
              <th>Event Date</th>
              <th>Contact Number</th>
              <th>Email</th>
              <th>Venue Name</th>
              <th>Expected Guests</th>
              <th>Package</th>
              <th>Event Type</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="booking in bookings" :key="booking.id">
              <td>{{ booking.full_name }}</td>
              <td>{{ formatDate(booking.event_date) }}</td>
              <td>{{ booking.contact_number }}</td>
              <td>{{ booking.email }}</td>
              <td>{{ booking.venue_name }}</td>
              <td>{{ booking.expected_guests }}</td>
              <td>{{ booking.package_name }}</td>
              <td>{{ booking.event_type }}</td>
            </tr>
          </tbody>
        </table>
        <a href="#">Show All</a>
      </div>
    </main>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import AdminSidebar from './AdminSidebar.vue';

const bookings = ref([]);

const fetchBookings = async () => {
  try {
    const token = localStorage.getItem('token');
    console.log('Fetching bookings with token:', token); // Add this line
    const response = await fetch('http://localhost:3000/api/bookings', {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    console.log('Response status:', response.status); // Add this line
    if (!response.ok) {
      const errorText = await response.text();
      console.error('Error response:', errorText); // Add this line
      throw new Error(`Failed to fetch bookings: ${response.status} - ${errorText}`);
    }
    const data = await response.json();
    console.log('Fetched bookings:', data); // Add this line
    bookings.value = data;
  } catch (error) {
    console.error('Error fetching bookings:', error);
  }
};

const formatDate = (dateString) => {
  const options = { year: 'numeric', month: 'short', day: 'numeric' };
  return new Date(dateString).toLocaleDateString('en-US', options);
};

onMounted(fetchBookings);
</script>

<style scoped>
.admin-dashboard {
  display: flex;
  height: 100vh;
  font-family: Arial, sans-serif;
  background-color: #f0f2f5;
}

main {
  flex-grow: 1;
  padding: 20px;
  background-color: #f8fafc;
  border-radius: 20px;
  box-shadow: 0 0 10px rgba(0,0,0,0.1);
}

.insights {
  display: grid;
  grid-template-columns: repeat(1, 1fr);
  gap: 20px;
  margin-bottom: 30px;
}

.insights > div {
  background-color: #ffffff;
  padding: 20px;
  border-radius: 20px;
  box-shadow: 0 4px 6px rgba(0,0,0,0.05);
}

.recent-bookings {
  background-color: #ffffff;
  padding: 20px;
  border-radius: 20px;
  box-shadow: 0 4px 6px rgba(0,0,0,0.05);
  margin-bottom: 20px;
}

table {
  width: 100%;
  border-collapse: separate;
  border-spacing: 0 10px;
}

th, td {
  padding: 12px;
  text-align: left;
  background-color: #ffffff;
}

tr {
  box-shadow: 0 2px 4px rgba(0,0,0,0.05);
}

th:first-child,
td:first-child {
  border-top-left-radius: 10px;
  border-bottom-left-radius: 10px;
}

th:last-child,
td:last-child {
  border-top-right-radius: 10px;
  border-bottom-right-radius: 10px;
}
</style>
