<template>
  <div class="wedding-package-section">
    <Navbar 
      @openLoginModal="openLoginModal"
      @openRegisterModal="openRegisterModal"
      @logout="handleLogout"
    />
    <h2 class="section-title">Premium Wedding Event Packages</h2>
    <div v-if="isLoading" class="loading">Loading packages...</div>
    <div v-else-if="error" class="error">{{ error }}</div>
    <div v-else class="packages-container">
      <div class="packages-wrapper">
        <div class="packages-row">
          <div v-for="product in weddingProducts" :key="product.id" class="package-card">
            <img :src="getImageUrl(product.image_path)" :alt="product.name" class="package-image" />
            <div class="package-details">
              <h3>{{ product.name }}</h3>
              <p v-if="userRole === 'user'" class="package-price">{{ formatPrice(product.price) }}</p>
              <p v-else class="login-message">Login to view price</p>
              <button class="package-link" @click="openModal(product)">View Details</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Product Modal -->
    <div v-if="selectedProduct" class="modal">
      <div class="modal-content">
        <button @click="closeModal" class="close-button">×</button>
        <h3>{{ selectedProduct.name }}</h3>
        <img :src="getImageUrl(selectedProduct.image_path)" :alt="selectedProduct.name" class="modal-image" />
        <p>{{ selectedProduct.description }}</p>
        <p class="package-price">{{ formatPrice(selectedProduct.price) }}</p>
        <button @click="bookNow" class="book-now-button">Book Now</button>
      </div>
    </div>

    <!-- Booking Modal -->
    <div v-if="isBookingModalOpen" class="modal booking-modal">
      <div class="modal-content booking-content">
        <button @click="closeBookingModal" class="close-button">×</button>
        <h3>Book Your Wedding Package</h3>
        <form @submit.prevent="submitBooking" class="booking-form">
          <!-- Step 1: Basic Information -->
          <div v-if="bookingStep === 1">
            <h4>Step 1: Basic Information</h4>
            <input v-model="bookingForm.fullName" placeholder="Full Name" required>
            <input v-model="bookingForm.eventDate" type="date" required>
            <input v-model="bookingForm.contactNumber" placeholder="Contact Number" required>
            <input v-model="bookingForm.email" type="email" placeholder="Email Address" required>
          </div>

          <!-- Step 2: Venue Details -->
          <div v-if="bookingStep === 2">
            <h4>Step 2: Venue Details</h4>
            <input v-model="bookingForm.venueName" placeholder="Venue Name" required>
            <input v-model="bookingForm.venueAddress" placeholder="Venue Address" required>
            <input v-model="bookingForm.expectedGuests" type="number" placeholder="Expected Number of Guests" required>
          </div>

          <!-- Step 3: Additional Information -->
          <div v-if="bookingStep === 3">
            <h4>Step 3: Additional Information</h4>
            <textarea v-model="bookingForm.specialRequests" placeholder="Special Requests or Additional Information"></textarea>
            <input v-model="bookingForm.referralSource" placeholder="How did you hear about us?">
          </div>

          <!-- Navigation buttons -->
          <div class="form-navigation">
            <button v-if="bookingStep > 1" @click="previousStep" type="button">Previous</button>
            <button v-if="bookingStep < 3" @click="nextStep" type="button">Next</button>
            <button v-if="bookingStep === 3" type="submit">Submit</button>
          </div>
        </form>
      </div>
    </div>

    <!-- Login and Register modals remain unchanged -->
    <Login
      v-if="isModalOpen && activeModal === 'login'"
      :isOpen="isModalOpen"
      @close="closeModal"
      @login="handleLogin"
      @switchToRegister="switchToRegister"
    />
    <Register
      v-if="isModalOpen && activeModal === 'register'"
      :isOpen="isModalOpen"
      @close="closeModal"
      @register="handleRegister"
      @switchToLogin="switchToLogin"
    />
  </div>
</template>

<script setup>
import { ref, onMounted, watch } from "vue";
import Navbar from "@/components/Navbar.vue";
import Login from "@/components/login.vue";
import Register from "@/components/register.vue";
import { useAuth } from '@/composables/useAuth';

const props = defineProps(['userRole']);

const { token } = useAuth();

const activeModal = ref(null);
const isModalOpen = ref(false);
const weddingProducts = ref([]);
const selectedProduct = ref(null);
const isLoading = ref(true);
const error = ref(null);
const userRole = ref(props.userRole);
const user = ref({
  id: null,
  username: '',
  email: '',
  firstName: '',
  lastName: '',
  phoneNumber: '',
  // Add any other relevant fields
});
const isBookingModalOpen = ref(false);
const bookingStep = ref(1);
const bookingForm = ref({
  fullName: '',
  eventDate: '',
  contactNumber: '',
  email: '',
  venueName: '',
  venueAddress: '',
  expectedGuests: '',
  specialRequests: '',
  referralSource: ''
});

watch(() => props.userRole, (newRole) => {
  if (newRole) {
    userRole.value = newRole;
  }
});

onMounted(async () => {
  await fetchUserInfo();
  fetchWeddingProducts();
});

const fetchUserInfo = async () => {
  try {
    if (!token.value) {
      console.error('No token found');
      return;
    }

    console.log('Fetching user info with token:', token.value);

    const response = await fetch('http://localhost:3000/user/profile', {
      headers: {
        'Authorization': token.value,
      },
    });

    console.log('User profile response status:', response.status);

    if (response.ok) {
      const userData = await response.json();
      console.log('Raw user data from server:', userData);
      user.value = {
        id: userData.id,
        username: userData.username,
        email: userData.email,
        fullName: userData.fullName,
        contactNo: userData.contactNo,
        // Add any other relevant fields
      };
      userRole.value = userData.role;
      console.log('Updated user:', user.value);

      // Pre-fill the booking form with user data
      bookingForm.value = {
        ...bookingForm.value,
        fullName: `${user.value.fullName}`,
        contactNumber: user.value.contactNo,
        email: user.value.email,
      };
    } else {
      throw new Error('Failed to fetch user data');
    }
  } catch (error) {
    console.error('Error fetching user info:', error);
  }
};

const fetchWeddingProducts = async () => {
  isLoading.value = true;
  error.value = null;
  try {
    const response = await fetch('http://localhost:3000/api/products?category=Wedding', {
      headers: {
        'Authorization': `Bearer ${token.value}`
      }
    });
    if (response.ok) {
      const data = await response.json();
      weddingProducts.value = data.filter(product => product.category.toLowerCase() === 'wedding');
      console.log('Fetched wedding products:', weddingProducts.value);
    } else {
      throw new Error('Failed to fetch wedding products');
    }
  } catch (err) {
    console.error('Error fetching wedding products:', err);
    error.value = 'Failed to load wedding packages. Please try again later.';
  } finally {
    isLoading.value = false;
  }
};

const getImageUrl = (imagePath) => {
  return `http://localhost:3000${imagePath}`;
};

const formatPrice = (price) => {
  return '₱' + new Intl.NumberFormat('en-PH').format(price);
};

const openModal = (product) => {
  selectedProduct.value = {
    ...product,
    price: userRole.value === 'user' ? product.price : 'Login to view price'
  };
  isModalOpen.value = true;
};

const closeModal = () => {
  selectedProduct.value = null;
  isModalOpen.value = false;
  // Add a slight delay before refreshing the page
  setTimeout(() => {
    window.location.reload();
  }, 100);
};

const openLoginModal = () => {
  isModalOpen.value = true;
  activeModal.value = 'login';
};

const openRegisterModal = () => {
  isModalOpen.value = true;
  activeModal.value = 'register';
};

const switchToRegister = () => {
  activeModal.value = 'register';
};

const switchToLogin = () => {
  activeModal.value = 'login';
};

const handleLogin = (credentials) => {
  console.log("Login credentials received:", credentials);
  closeModal();
};

const handleRegister = (userData) => {
  console.log("Registration data received:", userData);
  closeModal();
};

const handleLogout = () => {
  console.log("User logged out");
  // Implement any additional logout logic if needed
};

const bookNow = () => {
  isBookingModalOpen.value = true;
};

const closeBookingModal = () => {
  isBookingModalOpen.value = false;
  bookingStep.value = 1;
  // Reset form fields
  Object.keys(bookingForm.value).forEach(key => {
    bookingForm.value[key] = '';
  });
  // Add a slight delay before refreshing the page
  setTimeout(() => {
    window.location.reload();
  }, 100);
};

const nextStep = () => {
  if (bookingStep.value < 3) {
    bookingStep.value++;
  }
};

const previousStep = () => {
  if (bookingStep.value > 1) {
    bookingStep.value--;
  }
};

const submitBooking = async () => {
  try {
    console.log('Submitting booking:', bookingForm.value);
    const response = await fetch('http://localhost:3000/api/bookings', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token.value}`
      },
      body: JSON.stringify({
        ...bookingForm.value,
        packageId: selectedProduct.value.id,
        eventType: 'Wedding'
      })
    });

    console.log('Response status:', response.status);
    const responseText = await response.text();
    console.log('Response text:', responseText);

    if (response.ok) {
      const responseData = JSON.parse(responseText);
      alert(responseData.message);
      closeBookingModal();
    } else {
      throw new Error(responseText || 'Failed to submit booking');
    }
  } catch (error) {
    console.error('Error submitting booking:', error);
    alert('Failed to submit booking. Please try again. Error: ' + error.message);
  }
};
</script>

<style scoped>
@import url('https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap');

body {
  font-family: 'Roboto', sans-serif;
}

.wedding-package-section {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 2rem;
  background-color: #f0f0f0;
  min-height: 100vh;
  width: 100%;
}

.section-title {
  font-size: 2.5rem;
  font-weight: 700;
  margin-top: 5rem;
  margin-bottom: 2rem;
  text-align: center;
  color: #333;
}

.packages-container {
  width: 100%;
  overflow: hidden;
  padding: 1rem 0;
}

.packages-row {
  display: flex;
  flex-wrap: wrap;
  gap: 2rem;
  justify-content: flex-start; /* Change this from center to flex-start */
}

.package-card {
  flex: 0 0 calc(25% - 1.5rem); /* 25% width for 4 cards per row, accounting for gap */
  max-width: 300px;
  background: #fff;
  border-radius: 10px;
  box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
  overflow: hidden;
}

.package-image {
  width: 100%;
  height: 200px;
  object-fit: cover;
}

.package-details {
  padding: 1rem;
}

.package-details h3 {
  font-size: 1.4rem;
  margin: 0.5rem 0;
}

.package-price {
  font-size: 1.2rem;
  font-weight: 700;
  color: #ff6347;
  margin: 0.5rem 0;
}

.package-link {
  display: inline-block;
  background-color: #ff6347;
  color: white;
  border: none;
  cursor: pointer;
  margin-top: 0.5rem;
  font-size: 1rem;
  text-decoration: none;
  padding: 0.5rem 1rem;
  border-radius: 5px;
  transition: background-color 0.3s ease, color 0.3s ease;
}

.package-link:hover {
  background-color: #ff1100;
}

.loading, .error {
  text-align: center;
  font-size: 1.2rem;
  margin-top: 2rem;
}

.error {
  color: #ff0000;
}

/* Responsive design */
@media (max-width: 1200px) {
  .package-card {
    flex: 0 0 calc(33.333% - 1.33rem); /* 3 cards per row */
  }
}

@media (max-width: 900px) {
  .package-card {
    flex: 0 0 calc(50% - 1rem); /* 2 cards per row */
  }
}

@media (max-width: 600px) {
  .package-card {
    flex: 0 0 100%; /* 1 card per row */
  }
}

.modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  background: rgba(0, 0, 0, 0.5);
  z-index: 1000;
}

.modal-content {
  position: relative;
  background: #fff;
  padding: 2rem;
  border-radius: 15px;
  border: 1px solid #ddd;
  box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
  width: 90%;
  max-width: 600px;
  text-align: center;
  font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
  display: flex;
  flex-direction: column;
  align-items: center;
}

.modal-content h3 {
  font-size: 2.5rem;
  font-weight: 700;
  margin-bottom: 1rem;
  color: #333;
}

.close-button {
  position: absolute;
  top: 10px;
  right: 10px;
  background-color: transparent;
  color: #333;
  border: none;
  font-size: 1.5rem;
  cursor: pointer;
  padding: 0;
  line-height: 1;
  transition: color 0.3s ease;
}

.close-button:hover {
  color: #ff6347;
}

.modal-image {
  max-width: 100%;
  height: auto;
  margin-bottom: 1rem;
}

/* Add this new style to create a full-width container for alignment */
.packages-wrapper {
  width: calc(100% + 2rem); /* Account for the gap */
  margin-left: -1rem; /* Offset the container to align with the edge */
  padding: 0 1rem; /* Add padding to prevent cards from touching the edge */
}

.login-message {
  font-size: 1rem;
  color: #888;
  font-style: italic;
  margin: 0.5rem 0;
}

.book-now-button {
  background-color: #ff6347;
  color: white;
  border: none;
  padding: 0.75rem 1.5rem;
  font-size: 1.2rem;
  cursor: pointer;
  border-radius: 5px;
  transition: background-color 0.3s ease;
  margin-top: 1rem;
}

.booking-modal .modal-content {
  max-width: 500px;
  background-color: #f9f9f9;
  border-radius: 15px;
  padding: 2rem;
}

.booking-form {
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
}

.booking-form input,
.booking-form textarea {
  width: calc(100% - 20px);
  padding: 0.75rem 1rem;
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  font-size: 1rem;
  transition: border-color 0.3s ease, box-shadow 0.3s ease;
  background-color: #ffffff;
  margin-right: 20px;
  margin-bottom: 15px; /* Add margin to the bottom of each input */
}

.booking-form input:focus,
.booking-form textarea:focus {
  outline: none;
  border-color: #ff6347;
  box-shadow: 0 0 0 2px rgba(255, 99, 71, 0.2);
}

.booking-form input::placeholder,
.booking-form textarea::placeholder {
  color: #aaa;
}

.form-navigation {
  display: flex;
  justify-content: space-between;
  gap: 1rem;
  margin-top: 1.5rem;
}

.form-navigation button {
  padding: 0.75rem 1.5rem;
  background-color: #ff6347;
  color: white;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-size: 1rem;
  font-weight: 600;
  transition: background-color 0.3s ease, transform 0.1s ease;
  flex: 0 1 auto; /* Allow buttons to shrink but not grow */
  min-width: 120px; /* Set a minimum width for buttons */
  max-width: 45%; /* Limit maximum width to prevent overly wide buttons */
}

/* Specific style for the submit button */
.form-navigation button[type="submit"] {
  padding: 0.5rem 1rem;
  width: auto; /* Allow the button to size based on content */
  flex: 0 0 auto; /* Prevent the button from growing or shrinking */
}

.form-navigation button:hover {
  background-color: #ff5233;
}

.form-navigation button:active {
  transform: scale(0.98);
}
</style>