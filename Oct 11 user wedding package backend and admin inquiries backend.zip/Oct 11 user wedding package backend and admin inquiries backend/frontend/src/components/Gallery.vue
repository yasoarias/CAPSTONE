<template>
  <div class="gallery-page" :class="{ 'dark-mode': isDarkMode }">
    <Navbar 
      @openLoginModal="openLoginModal"
      @openRegisterModal="openRegisterModal"
      @logout="handleLogout"
    />
    <div class="content-wrapper">
      <aside v-if="isLoggedIn" class="filter-sidebar">
        <h2>SEARCH FILTER</h2>
        <div class="filter-section">
          <h3>By Category</h3>
          <div v-for="category in categories" :key="category" class="category-item">
            <label>
              <input type="checkbox" v-model="selectedCategories" :value="category">
              <span>{{ category }}</span>
            </label>
          </div>
          <a href="#" class="more-link">More</a>
        </div>
        <div class="filter-section">
          <h3>By Rating</h3>
          <div v-for="rating in [5, 4, 3, 2, 1]" :key="rating" class="rating-item">
            <label>
              <input type="checkbox" v-model="selectedRatings" :value="rating">
              <span class="stars">
                <i v-for="star in rating" :key="star" class="fas fa-star"></i>
              </span>
              <span>& Up</span>
            </label>
          </div>
          <a href="#" class="more-link">More</a>
        </div>
        <div class="filter-section">
          <h3>Price Range</h3>
          <div class="price-inputs">
            <input v-model="minPrice" type="number" placeholder="Min -">
            <input v-model="maxPrice" type="number" placeholder="Max +">
          </div>
        </div>
        <button @click="applyFilters" class="apply-filters">Apply Filters</button>
      </aside>
      <main :class="{ 'with-sidebar': isLoggedIn }">
        <h1 class="gallery-title">Gallery</h1>
        <div class="gallery-grid">
          <div v-for="product in filteredProducts" :key="product.id" class="gallery-item" @click="openModal(product)">
            <img :src="getImageUrl(product.image_path)" :alt="product.name" class="gallery-image" />
            <div class="gallery-item-info">
              <h3>{{ product.name }}</h3>
              <p>{{ product.category }}</p>
            </div>
          </div>
        </div>
      </main>
    </div>

    <!-- Image Modal -->
    <div v-if="selectedProduct" class="modal" @click="closeModal">
      <div class="modal-content" @click.stop>
        <span class="close" @click="closeModal">✖</span> <!-- Change to X -->
        <img :src="getImageUrl(selectedProduct.image_path)" :alt="selectedProduct.name" class="modal-image" />
        <h2 class="product-title">{{ selectedProduct.name }}</h2>
        <p class="description">{{ selectedProduct.description }}</p>
        <div class="package-info">
          <h3>Package Information:</h3>
          <p>Category: {{ selectedProduct.category }}</p>
          <p>Price: ${{ formatPrice(selectedProduct.price) }}</p>
          <div class="ratings">
            <span>Ratings: {{ averageRating.toFixed(1) }} ({{ totalRatings }} ratings)</span>
            <div class="rating-stars">
              <i v-for="star in 5" :key="star" class="fas fa-star" :class="{ 'filled': star <= Math.round(averageRating) }"></i>
            </div>
            <div class="user-rating">
              <span v-if="selectedProduct.userRating">Your rating:</span>
              <div v-if="selectedProduct.userRating" class="rating-stars">
                <i v-for="star in 5" :key="star" class="fas fa-star" :class="{ 'filled': star <= selectedProduct.userRating }"></i>
              </div>
              <span v-if="selectedProduct.userRating" class="rated-indicator">Rated</span>
          
            </div>
          </div>
          <button @click="viewComments(selectedProduct.id)">View Comments</button>
          
        </div>
        <!-- Comments Modal -->
        <transition name="fade">
          <div v-if="isCommentsModalOpen" class="comments-modal">
            <div class="comments-header">
              <h3>Comments ({{ comments.length }})</h3>
              <p class="close-comments" @click="closeCommentsModal">Close Comments</p>
            </div>
            <div v-if="comments.length === 0">No comments yet.</div>
            <ul v-else>
              <li v-for="comment in comments" :key="comment.id" class="comment-item">
                <img :src="comment.profilePicture || defaultProfileImage" alt="User Profile" class="profile-picture" />
                <div class="comment-text">
                  <strong>{{ comment.fullName }}</strong>: {{ comment.text }}
                </div>
              </li>
            </ul>
            <div class="comment-input-container">
              <textarea v-model="newComment" placeholder="Add a comment..." class="comment-input"></textarea>
              <button @click="addComment" class="submit-comment">Submit Comment</button>
            </div>
          </div>
        </transition>
      </div>
    </div>

    <!-- Confirmation Modal -->
    <div v-if="isConfirmationModalOpen" class="modal" @click="closeConfirmationModal">
      <div class="modal-content" @click.stop>
        <span class="close" @click="closeConfirmationModal">&times;</span>
        <h2>Confirm Rating</h2>
        <p>Are you sure you want to rate this {{ selectedRating }} stars?</p>
        <textarea v-model="feedback" placeholder="Leave your feedback..."></textarea>
        <button @click="submitRating(selectedProductId, selectedRating)">Submit Rating</button>
      </div>
    </div>

    <!-- Login and Register modals remain unchanged -->
    <Login
      v-if="isModalOpen && activeModal === 'login'"
      :isOpen="isModalOpen"
      @close="closeModal"
      @login="handleLogin"
      @switchToRegister="switchToRegister"
    />
    <Register
      v-if="isModalOpen && activeModal === 'register'"
      :isOpen="isModalOpen"
      @close="closeModal"
      @register="handleRegister"
      @switchToLogin="switchToLogin"
    />
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from "vue";
import Navbar from "./Navbar.vue";
import Login from "./login.vue";
import Register from "./register.vue";
import defaultProfileImage from '@/assets/default-profile.png'; 
import { useAuth } from '@/composables/useAuth'; // Import the composable

const { token } = useAuth(); // Use the composable to access the token

const isDarkMode = ref(false);
const isLoggedIn = ref(false);
const isModalOpen = ref(false);
const activeModal = ref("login");
const selectedProduct = ref(null);
const products = ref([]);
const showLoginModal = ref(false);
const showRegisterModal = ref(false);
const isAdmin = ref(false);
const showFilterSidebar = ref(true);
const galleryAlignment = ref('center');

onMounted(() => {
  isLoggedIn.value = !!localStorage.getItem('token');
  isAdmin.value = localStorage.getItem('userRole') === 'admin'; // Assuming you store the user role in localStorage
  fetchProducts();
  
});

// New refs for filtering
const searchQuery = ref('');
const selectedCategories = ref([]);
const minPrice = ref('');
const maxPrice = ref('');
const selectedRatings = ref([]);

const categories = ['Wedding', 'Christening', 'Kiddie Party', 'Debut'];

const fetchProducts = async () => {
  try {
    const response = await fetch('http://localhost:3000/api/products', {
      headers: {
        'Authorization': `Bearer ${token.value}`
      }
    });
    if (response.ok) {
      const data = await response.json();
      products.value = data.map(product => ({
        ...product,
        hoverRating: 0
      }));
      console.log('Fetched products:', products.value); // Debug log
    } else {
      console.error('Failed to fetch products');
    }
  } catch (error) {
    console.error('Error fetching products:', error);
  }
};

const getImageUrl = (imagePath) => {
  return `http://localhost:3000${imagePath}`;
};

const truncateDescription = (description, maxLength = 50) => {
  if (description.length <= maxLength) return description;
  return description.slice(0, maxLength) + '...';
};

const formatPrice = (price) => {
  return new Intl.NumberFormat('en-US').format(price);
};

const openModal = async (product) => {
  selectedProduct.value = { ...product };
  await fetchAverageRating(product.id);
  await fetchUserRating(product.id);
};

const closeAllModals = () => {
  closeModal();
  closeCommentsModal();
};

const closeModal = () => {
  selectedProduct.value = null;
  isModalOpen.value = false;
  closeCommentsModal(); // Ensure comments modal is also closed
};

// New computed property for filtered products
const filteredProducts = computed(() => {
  return products.value.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.value.toLowerCase()) ||
                          product.description.toLowerCase().includes(searchQuery.value.toLowerCase());
    const matchesCategory = selectedCategories.value.length === 0 || 
                            selectedCategories.value.map(cat => cat.toLowerCase()).includes(product.category.toLowerCase());
    const matchesPrice = (!minPrice.value || product.price >= Number(minPrice.value)) &&
                         (!maxPrice.value || product.price <= Number(maxPrice.value));
    const matchesRating = selectedRatings.value.length === 0 || 
                          selectedRatings.value.some(rating => product.rating >= rating);
    return matchesSearch && matchesCategory && matchesPrice && matchesRating;
  });
});

const applyFilters = () => {
  // This function is called when the "Apply Filters" button is clicked
  // The filtering is already handled by the computed property, so we don't need to do anything here
  // You could add additional logic here if needed
};


const handleLogout = () => {
  localStorage.removeItem('token');
  isLoggedIn.value = false;
};


const openLoginModal = () => {
  isModalOpen.value = true;
  activeModal.value = "login";
};

const openRegisterModal = () => {
  isModalOpen.value = true;
  activeModal.value = "register";
};
const handleLogin = (credentials) => {
  console.log("Login credentials received:", credentials);
  closeModal();
};

const handleRegister = (userData) => {
  console.log("Registration data received:", userData);
  closeModal();
};

const hoverRating = ref(0);
const isConfirmationModalOpen = ref(false);
const selectedRating = ref(0);
const selectedProductId = ref(null);
const feedback = ref('');

const openConfirmationModal = (productId, rating) => {
  event.stopPropagation(); // Prevent the gallery item click event
  selectedProductId.value = productId;
  selectedRating.value = rating;
  isConfirmationModalOpen.value = true;
};

const closeConfirmationModal = () => {
  isConfirmationModalOpen.value = false;
  feedback.value = ''; // Clear feedback
};

const submitRating = async (productId, rating) => {
  try {
    const response = await fetch(`http://localhost:3000/api/products/${productId}/rate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      },
      body: JSON.stringify({ rating })
    });
    if (response.ok) {
      const updatedProduct = await response.json();
      // Update the product's user rating in the local state
      const product = products.value.find(p => p.id === productId);
      if (product) {
        product.userRating = updatedProduct.userRating; // Assuming the API returns the updated rating
      }
      closeConfirmationModal(); // Close modal after submission
    } else {
      console.error('Failed to rate product');
    }
  } catch (error) {
    console.error('Error rating product:', error);
  }
};

const isCommentsModalOpen = ref(false);
const comments = ref([]);
const newComment = ref('');

const viewComments = async (productId) => {
    console.log(`Viewing comments for product ID: ${productId}`);
    try {
        const response = await fetch(`http://localhost:3000/api/products/${productId}/comments`, {
            headers: {
                'Authorization': `Bearer ${token.value}`
            }
        });
        if (response.ok) {
            const fetchedComments = await response.json();
            comments.value = fetchedComments.map(comment => ({
                ...comment,
                profilePicture: comment.profilePicture ? `http://localhost:3000${comment.profilePicture}` : defaultProfileImage
            }));
            openCommentsModal();
        } else {
            console.error('Failed to fetch comments:', await response.text());
        }
    } catch (error) {
        console.error('Error fetching comments:', error);
    }
};

const openCommentsModal = () => {
    isCommentsModalOpen.value = true;
};

const closeCommentsModal = () => {
    isCommentsModalOpen.value = false;
    newComment.value = ''; // Clear the input
};

const addComment = async () => {
    if (newComment.value.trim()) {
        try {
            const response = await fetch(`http://localhost:3000/api/products/${selectedProduct.value.id}/comments`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token.value}`
                },
                body: JSON.stringify({ text: newComment.value })
            });

            if (response.ok) {
                const addedComment = await response.json();
                comments.value.push({
                    id: addedComment.id,
                    profilePicture: addedComment.profilePicture ? `http://localhost:3000${addedComment.profilePicture}` : defaultProfileImage,
                    fullName: addedComment.fullName,
                    text: newComment.value
                });
                newComment.value = '';
            } else {
                const errorData = await response.json();
                console.error('Failed to add comment:', errorData);
            }
        } catch (error) {
            console.error('Error adding comment:', error);
        }
    }
};

const averageRating = ref(0);
const totalRatings = ref(0);

const fetchAverageRating = async (productId) => {
  try {
    const response = await fetch(`http://localhost:3000/api/products/${productId}/average-rating`, {
      headers: {
        'Authorization': `Bearer ${token.value}`
      }
    });
    if (response.ok) {
      const data = await response.json();
      console.log('Fetched rating data:', data); // Add this line for debugging
      averageRating.value = parseFloat(data.averageRating) || 0;
      totalRatings.value = data.totalRatings || 0;
    } else {
      console.error('Failed to fetch average rating');
      averageRating.value = 0;
      totalRatings.value = 0;
    }
  } catch (error) {
    console.error('Error fetching average rating:', error);
    averageRating.value = 0;
    totalRatings.value = 0;
  }
};

const getStarStyle = (starPosition) => {
  const fullStars = Math.floor(averageRating.value);
  const decimalPart = averageRating.value - fullStars;
  
  if (starPosition <= fullStars) {
    return { width: '100%' };
  } else if (starPosition === fullStars + 1 && decimalPart > 0) {
    return { width: `${decimalPart * 100}%` };
  } else {
    return { width: '0%' };
  }
};

const fetchUserRating = async (productId) => {
  try {
    const response = await fetch(`http://localhost:3000/api/products/${productId}/user-rating`, {
      headers: {
        'Authorization': `Bearer ${token.value}`
      }
    });
    if (response.ok) {
      const data = await response.json();
      selectedProduct.value.userRating = data.userRating;
    } else {
      console.error('Failed to fetch user rating');
    }
  } catch (error) {
    console.error('Error fetching user rating:', error);
  }
};

const openFeedbackModal = () => {
  if (!selectedProduct.value.userRating) {
    isConfirmationModalOpen.value = true;
  }
};

</script>

<style scoped>
.gallery-page {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
  background-color: #f5f5f5; /* Light background color */
}

.content-wrapper {
  display: flex;
  flex: 1;
  height: calc(100vh - 60px); /* Adjust 60px to match your navbar height */
  overflow: hidden; /* Prevent scrolling on the wrapper */
}

.filter-sidebar {
  width: 250px;
  background-color: #fff;
  box-shadow: 2px 0 5px rgba(0,0,0,0.1);
  padding: 20px;/* Allow scrolling within the sidebar if content overflows */
  height: 100%; /* Take full height of the parent */
  position: sticky;
  top: 90px; /* Adjust based on your navbar height */
}

main {
  flex: 1;
  padding: 20px;
  overflow-y: auto; /* Allow scrolling in the main content area */
  height: 100%; /* Take full height of the parent */
}

/* Responsive adjustments */
@media (max-width: 768px) {
  .content-wrapper {
    flex-direction: column;
    height: auto; /* Allow content to determine height on mobile */
  }

  .filter-sidebar {
    width: 100%;
    height: auto; /* Allow content to determine height on mobile */
    position: static; /* Remove sticky positioning on mobile */
    margin-bottom: 20px;
  }

  main {
    height: auto; /* Allow content to determine height on mobile */
  }
}

/* Dark mode adjustments */
.dark-mode .filter-sidebar {
  background-color: #333;
  color: #fff;
}

/* Additional styles remain unchanged */

.gallery-title {
  margin-top: 60px;
}

.gallery-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); /* Larger grid items */
  gap: 20px;
  padding-top: 20px; /* Add some top padding to prevent overlap with navbar */
}

.gallery-item {
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
  transition: transform 0.3s ease;
  cursor: pointer;
}

.gallery-item:hover {
  transform: translateY(-5px);
}

.gallery-image {
  width: 100%;
  height: 250px; /* Increased height */
  object-fit: cover;
}

.gallery-item-info {
  padding: 10px;
  background-color: #f8f8f8;
}

.gallery-item-info h3 {
  margin: 0 0 5px 0;
  font-size: 1.1em;
}

.gallery-item-info p {
  margin: 0;
  font-size: 0.9em;
}

/* Responsive adjustments */
@media (max-width: 1200px) {
  .gallery-grid {
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
  }
}

@media (max-width: 992px) {
  .gallery-grid {
    grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  }
}

@media (max-width: 768px) {
  .gallery-container {
    flex-direction: column;
  }

  .filter-sidebar {
    width: 100%;
    margin-right: 0;
    margin-bottom: 20px;
  }

  .gallery-grid {
    grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
  }
}

/* Modal styles */
.modal {
  position: fixed;
  z-index: 1000;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  overflow: auto;
  background-color: rgba(0,0,0,0.8);
  display: flex;
  justify-content: center;
  align-items: center;
}

.modal-content {
  background-color: #fefefe;
  margin: auto;
  padding: 20px;
  border: 1px solid #888;
  width: 80%;
  max-width: 500px;
  border-radius: 8px;
  position: relative;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

.close {
  color: #aaaaaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
  cursor: pointer;
}

.close:hover,
.close:focus {
  color: #000;
  text-decoration: none;
  cursor: pointer;
}

.modal-image {
  width: 100%;
  max-height: 400px;
  object-fit: contain;
}

.description {
  margin-top: 15px;
  margin-bottom: 20px;
  line-height: 1.6;
}

.package-info {
  background-color: #f0f0f0;
  padding: 15px;
  border-radius: 8px;
  margin-top: 20px;
}

.package-info h3 {
  margin-top: 0;
  margin-bottom: 10px;
}

.package-info p {
  margin: 5px 0;
}

/* Dark mode styles for modal */
.dark-mode .modal-content {
  background-color: #333;
  color: #fff;
}

.dark-mode .close {
  color: #fff;
}

.dark-mode .package-info {
  background-color: #444;
}

/* New styles for filter sidebar */
.filter-sidebar {
  width: 200px;
  padding: 20px;
  background-color: #fff;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
  margin-right: 20px;
}

.filter-sidebar h2 {
  margin-bottom: 20px;
}

.filter-section {
  margin-bottom: 20px;
}

.filter-section h3 {
  margin-bottom: 10px;
}

.search-bar input,
.filter-section input[type="number"] {
  width: 100%;
  padding: 8px;
  margin-bottom: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

.filter-sidebar button {
  width: 100%;
  padding: 10px;
  background-color: #4CAF50;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

.filter-sidebar button:hover {
  background-color: #45a049;
}

main {
  flex: 1;
}

main.with-sidebar {
  margin-left: 20px;
}

/* Responsive adjustments */
@media (max-width: 768px) {
  .gallery-container {
    flex-direction: column;
  }

  .filter-sidebar {
    width: 100%;
    margin-right: 0;
    margin-bottom: 20px;
  }

  main.with-sidebar {
    margin-left: 0;
  }
}

/* Dark mode styles for new elements */
.dark-mode .filter-sidebar {
  background-color: #333;
  color: #fff;
}

.dark-mode .search-bar input,
.dark-mode .filter-section input[type="number"] {
  background-color: #444;
  color: #fff;
  border-color: #555;
}

.dark-mode .filter-sidebar button {
  background-color: #4CAF50;
}

.dark-mode .filter-sidebar button:hover {
  background-color: #45a049;
}

.filter-section input[type="number"] {
  width: calc(50% - 5px);
  padding: 8px;
  margin-bottom: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

.filter-section .price-inputs {
  display: flex;
  justify-content: space-between;
}

.filter-sidebar {
  width: 250px;
  padding: 20px;
  background-color: #fff;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
  margin-right: 30px;
  height: fit-content;
  align-self: flex-start;
}

.filter-sidebar h2 {
  font-size: 1.2em;
  margin-bottom: 20px;
  color: #333;
}

.filter-section {
  margin-bottom: 20px;
  border-bottom: 1px solid #e0e0e0;
  padding-bottom: 15px;
}

.filter-section:last-child {
  border-bottom: none;
}

.filter-section h3 {
  font-size: 1em;
  margin-bottom: 10px;
  color: #666;
}

.category-item, .rating-item {
  margin-bottom: 5px;
}

.category-item label, .rating-item label {
  display: flex;
  align-items: center;
  cursor: pointer;
}

.category-item input[type="checkbox"], .rating-item input[type="checkbox"] {
  margin-right: 8px;
}

.stars {
  color: #ffc107;
  margin-right: 5px;
}

.more-link {
  display: block;
  margin-top: 5px;
  color: #1a73e8;
  text-decoration: none;
  font-size: 0.9em;
}

.price-inputs {
  display: flex;
  justify-content: space-between;
}

.price-inputs input {
  width: calc(50% - 5px);
  padding: 8px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

.apply-filters {
  width: 100%;
  padding: 10px;
  background-color: #4CAF50;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.3s;
}

.apply-filters:hover {
  background-color: #45a049;
}

/* Dark mode styles */
.dark-mode .filter-sidebar {
  background-color: #333;
  color: #fff;
}

.dark-mode .filter-sidebar h2,
.dark-mode .filter-section h3 {
  color: #fff;
}

.dark-mode .filter-section {
  border-bottom-color: #555;
}

.dark-mode .more-link {
  color: #64B5F6;
}

.dark-mode .price-inputs input {
  background-color: #444;
  color: #fff;
  border-color: #555;
}

.dark-mode .apply-filters {
  background-color: #4CAF50;
}

.dark-mode .apply-filters:hover {
  background-color: #45a049;
}

.rating-section {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: 5px;
}

.rating {
  display: flex;
}

.star {
  cursor: pointer;
  color: #ccc;
  font-size: 1.2em;
  transition: color 0.2s;
}

.star.filled {
  color: #ffd700; /* Gold color for filled stars */
}

.rated-indicator {
  background-color: #4CAF50;
  color: white;
  padding: 2px 6px;
  border-radius: 4px;
  font-size: 0.8em;
  margin-left: 5px;
}

button {
  margin-left: 10px;
  padding: 5px 10px;
  background-color: #4CAF50;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

button:hover {
  background-color: #45a049;
}

textarea {
  width: 100%;
  height: 100px;
  margin-top: 10px;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
  resize: none; /* Prevent resizing */
  font-size: 1em; /* Increase font size */
  transition: border-color 0.3s, box-shadow 0.3s; /* Smooth transition */
}

textarea:focus {
  border-color: #4CAF50; /* Change border color on focus */
  box-shadow: 0 0 5px rgba(76, 175, 80, 0.5); /* Add shadow on focus */
}

textarea::placeholder {
  color: #aaa; /* Placeholder color */
  font-style: italic; /* Italicize placeholder */
}

/* Button styles */
button {
  margin-top: 10px; /* Add margin to separate from textarea */
  padding: 10px 15px;
  background-color: #4CAF50;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.3s; /* Smooth transition */
}

button:hover {
  background-color: #45a049; /* Darker green on hover */
}

/* Comments Modal styles */
.modal-content {
  max-width: 600px; /* Adjust as needed */
  width: 90%; /* Responsive width */

}


textarea {
  width: 100%;
  height: 60px;
  margin-top: 10px;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
  resize: none; /* Prevent resizing */
}

/* Comments Modal styles */
.comments-modal {
  position: fixed; /* Fixed position to overlay */
  top: 75%; /* Center vertically */
  left: 50%; /* Center horizontally */
  transform: translate(-50%, -50%); /* Centering */
  background-color: rgba(255, 255, 255); /* Slightly more opaque background */
  border-radius: 12px; /* Rounded corners */
  padding: 20px; /* Padding for spacing */
  width: 90%; /* Adjusted width to match parent */
  max-width: 600px; /* Maximum width */
  height: calc(100vh - 540px); /* Adjust height to fit within the modal */
  overflow-y: auto; /* Scroll if content exceeds */
  z-index: 10; /* Higher z-index to overlay correctly */
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Shadow for depth */
  display: flex; /* Use flexbox for layout */
  flex-direction: column; /* Stack children vertically */
    border: grey;
    border-style: solid;
    border-width: 1px;
  font-family: sans-serif;
}

/* Comments header styles */
.comments-header {
  display: flex; /* Flexbox for layout */
  justify-content: space-between; /* Space between title and button */
  align-items: center; /* Center vertically */
}

/* Comments list styles */
.comments-modal ul {
  list-style: none; /* Remove default list styling */
  padding: 0; /* Remove padding */
  margin: 0; /* Remove margin */
  flex-grow: 1; /* Allow the list to grow and fill space */
}

/* Close button styles */
.close-comments {
  background: none; /* No background */
  border: 1px solid black; /* Grey border */
  border-radius: 4px; /* Rounded corners */
  padding: 5px 10px; /* Padding */
  cursor: pointer; /* Pointer cursor */
  border-width: 2px solid black;
  color: grey;
  font-size: 12px;
  font-weight: bold;
}

.close-comments:hover {
 
  text-decoration: underline;
}

.comments-modal li {
  margin-bottom: 10px; /* Space between comments */
  font-size: 14px; /* Adjust font size */
}

/* Textarea styles */
textarea {
  width: 100%;
  height: 60px;
  margin-top: 10px;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
  resize: none; /* Prevent resizing */
}

/* Fade transition */
.fade-enter-active, .fade-leave-active {
  transition: opacity 0.5s;
}
.fade-enter, .fade-leave-to /* .fade-leave-active in <2.1.8 */ {
  opacity: 0;
}

/* Comment input styles */
.comment-input {
  width: 70%; /* Adjust width */
  height: 40px; /* Smaller height */
  padding: 5px; /* Padding */
  border: 1px solid #ccc; /* Border */
  border-radius: 4px; /* Rounded corners */
  resize: none; /* Prevent resizing */
}

/* Submit button styles */
.submit-comment {
  margin-left: 10px; /* Space between input and button */
  padding: 15px 10px; /* Padding */
  background-color: #4CAF50; /* Green background */
  color: white; /* White text */
  border: none; /* No border */
  border-radius: 4px; /* Rounded corners */
  cursor: pointer; /* Pointer cursor */
}

/* Comment input container */
.comment-input-container {
  display: flex; /* Use flexbox for layout */
  align-items: center; /* Center vertically */
  margin-top: 10px; /* Space above */
}

.profile-picture {
  width: 40px; /* Adjust size as needed */
  height: 40px; /* Adjust size as needed */
  border-radius: 50%; /* Make it circular */
  margin-right: 10px; /* Space between image and text */
}

.profile-picture {
  width: 40px; /* Adjust size as needed */
  height: 40px; /* Adjust size as needed */
  border-radius: 50%; /* Make it circular */
  margin-right: 10px; /* Space between image and text */
}

.comment-item {
  display: flex; /* Use flexbox for layout */
  align-items: center; /* Center vertically */
  margin-bottom: 10px; /* Space between comments */
}

.comment-text {
  margin-left: 10px; /* Space between image and text */
}

.rating-stars {
  display: inline-flex;
  font-size: 24px;
}

.star-container {
  position: relative;
  display: inline-block;
  color: #ddd; /* Empty star color */
}

.star-container i {
  position: absolute;
  top: 0;
  left: 0;
  overflow: hidden;
  color: #ffd700; /* Filled star color */
  transition: width 0.3s ease-in-out;
}

.ratings {
  display: flex;
  align-items: center;
  margin-bottom: 10px;
}

.ratings span {
  margin-right: 10px;
}

.rating-stars {
  display: inline-flex;
}

.star {
  color: #ddd;
  font-size: 18px;
  margin-right: 2px;
}

.star .filled {
  color: #ffd700;
}

.rating-stars {
  display: inline-flex;
  margin-left: 10px;
}

.rating-stars i {
  color: #ddd; /* Empty star color */
  font-size: 24px;
  margin-right: 2px;
}

.rating-stars i.filled {
  color: #ffd700; /* Filled star color */
}

.user-rating {
  display: flex;
  align-items: center;
  margin-top: 10px;
}

.user-rating span {
  margin-right: 10px;
}

.rated-indicator {
  background-color: #4CAF50;
  color: white;
  padding: 2px 6px;
  border-radius: 4px;
  font-size: 0.8em;
  margin-left: 10px;
}

.rate-btn {
  margin-left: 10px;
  padding: 5px 10px;
  background-color: #4CAF50;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 0.9em;
}

.rate-btn:hover {
  background-color: #45a049;
}
</style>