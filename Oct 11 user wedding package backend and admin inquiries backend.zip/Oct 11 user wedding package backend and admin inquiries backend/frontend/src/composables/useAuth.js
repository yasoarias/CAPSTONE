import { ref } from 'vue';

const token = ref(localStorage.getItem('token'));

const setToken = (newToken) => {
    token.value = newToken;
    localStorage.setItem('token', newToken);
};

const clearToken = () => {
    token.value = null;
    localStorage.removeItem('token');
};

export function useAuth() {
    return {
        token,
        setToken,
        clearToken
    };
}
