<template>
  <div class="booked-history-page">
    <Navbar 
      @openLoginModal="openLoginModal"
      @openRegisterModal="openRegisterModal"
      @logout="handleLogout"
    />
    <h1>Booked History</h1>
    <div class="recent-bookings">
      <h2>Recent Bookings</h2>
      <table>
        <thead>
          <tr>
            <th>Booking ID</th>
            <th>Event Type</th>
            <th>Event Date</th>
            <th>Venue</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="booking in paginatedBookings" :key="booking.id">
            <td>{{ booking.id }}</td>
            <td>{{ booking.event_type }}</td>
            <td>{{ formatDate(booking.event_date) }}</td>
            <td>{{ booking.venue_name }}</td>
            <td>{{ booking.status }}</td>
          </tr>
        </tbody>
      </table>
      <div class="pagination">
        <button
          @click="prevPage"
          :disabled="currentPage === 1"
          class="btn-pagination"
        >
          Previous
        </button>
        <span>Page {{ currentPage }} of {{ totalPages }}</span>
        <button
          @click="nextPage"
          :disabled="currentPage === totalPages"
          class="btn-pagination"
        >
          Next
        </button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from "vue";
import Navbar from '@/components/Navbar.vue';
import { useAuth } from "../composables/useAuth";

const { token } = useAuth();

const bookings = ref([]);
const currentPage = ref(1);
const itemsPerPage = 10;

const paginatedBookings = computed(() => {
  const start = (currentPage.value - 1) * itemsPerPage;
  const end = start + itemsPerPage;
  return bookings.value.slice(start, end);
});

const totalPages = computed(() =>
  Math.ceil(bookings.value.length / itemsPerPage)
);

const nextPage = () => {
  if (currentPage.value < totalPages.value) {
    currentPage.value++;
  }
};

const prevPage = () => {
  if (currentPage.value > 1) {
    currentPage.value--;
  }
};

const formatDate = (dateString) => {
  const options = { year: "numeric", month: "long", day: "numeric" };
  return new Date(dateString).toLocaleDateString(undefined, options);
};

const openLoginModal = () => {
  // Implementation
};

const openRegisterModal = () => {
  // Implementation
};

const handleLogout = () => {
  // Implementation
};

onMounted(async () => {
  try {
    const response = await fetch("http://localhost:3000/api/bookings", {
      headers: {
        Authorization: `Bearer ${token.value}`,
      },
    });
    if (response.ok) {
      bookings.value = await response.json();
    } else {
      console.error("Failed to fetch bookings");
    }
  } catch (error) {
    console.error("Error fetching bookings:", error);
  }
});
</script>

<style scoped>
.booked-history-page {
  padding: 2rem;
}

h1,
h2 {
  margin-bottom: 1rem;
}

table {
  width: 100%;
  border-collapse: collapse;
  margin-bottom: 1rem;
}

th,
td {
  padding: 0.75rem;
  text-align: left;
  border-bottom: 1px solid #ddd;
}

th {
  background-color: #f2f2f2;
  font-weight: bold;
}

.pagination {
  display: flex;
  justify-content: center;
  align-items: center;
  margin-top: 1rem;
}

.btn-pagination {
  background-color: #007bff;
  color: white;
  border: none;
  padding: 0.5rem 1rem;
  margin: 0 0.5rem;
  cursor: pointer;
  border-radius: 4px;
}

.btn-pagination:disabled {
  background-color: #ccc;
  cursor: not-allowed;
}
</style>
