<template>
  <div class="kiddie-party-package">
    <Navbar 
      @openLoginModal="openLoginModal"
      @openRegisterModal="openRegisterModal"
      @logout="handleLogout"
    />
    <h2 class="section-title">Kiddie Party Event Packages</h2>
    <div v-if="isLoading" class="loading">Loading packages...</div>
    <div v-else-if="error" class="error">{{ error }}</div>
    <div v-else class="packages-container">
      <div class="packages-wrapper">
        <div class="packages-row">
          <div v-for="product in kiddiePartyProducts" :key="product.id" class="package-card">
            <img :src="getImageUrl(product.image_path)" :alt="product.name" class="package-image" />
            <div class="package-details">
              <h3>{{ product.name }}</h3>
              <p v-if="userRole === 'user'" class="package-price">{{ formatPrice(product.price) }}</p>
              <p v-else class="login-message">Login to view price</p>
              <button class="package-link" @click="openModal(product)">View Details</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Product Modal -->
    <div v-if="selectedProduct" class="modal">
      <div class="modal-content">
        <button @click="closeModal" class="close-button">×</button>
        <h3>{{ selectedProduct.name }}</h3>
        <img :src="getImageUrl(selectedProduct.image_path)" :alt="selectedProduct.name" class="modal-image" />
        <p>{{ selectedProduct.description }}</p>
        <p class="package-price">{{ formatPrice(selectedProduct.price) }}</p>
        <button @click="bookNow" class="book-now-button">Book Now</button>
      </div>
    </div>

    <!-- Booking Modal -->
    <div v-if="isBookingModalOpen" class="modal booking-modal">
      <div class="modal-content booking-content">
        <button @click="closeBookingModal" class="close-button">×</button>
        <h3>Book Your Kiddie Party Package</h3>
        <form @submit.prevent="submitBooking" class="booking-form">
          <!-- Step 1: Basic Information -->
          <div v-if="bookingStep === 1">
            <h4>Step 1: Basic Information</h4>
            <input v-model="bookingForm.fullName" placeholder="Full Name" required>
            <input v-model="bookingForm.eventDate" type="date" required>
            <input v-model="bookingForm.contactNumber" placeholder="Contact Number" required>
            <input v-model="bookingForm.email" type="email" placeholder="Email Address" required>
          </div>

          <!-- Step 2: Venue Details -->
          <div v-if="bookingStep === 2">
            <h4>Step 2: Venue Details</h4>
            <input v-model="bookingForm.venueName" placeholder="Venue Name" required>
            <input v-model="bookingForm.venueAddress" placeholder="Venue Address" required>
            <input v-model="bookingForm.expectedGuests" type="number" placeholder="Expected Number of Guests" required>
          </div>

          <!-- Step 3: Additional Information -->
          <div v-if="bookingStep === 3">
            <h4>Step 3: Additional Information</h4>
            <textarea v-model="bookingForm.specialRequests" placeholder="Special Requests or Additional Information"></textarea>
            <input v-model="bookingForm.referralSource" placeholder="How did you hear about us?">
          </div>

          <!-- Navigation buttons -->
          <div class="form-navigation">
            <button v-if="bookingStep > 1" @click="previousStep" type="button">Previous</button>
            <button v-if="bookingStep < 3" @click="nextStep" type="button">Next</button>
            <button v-if="bookingStep === 3" type="submit">Submit</button>
          </div>
        </form>
      </div>
    </div>

    <!-- Login and Register modals remain unchanged -->
    <Login
      v-if="isModalOpen && activeModal === 'login'"
      :isOpen="isModalOpen"
      @close="closeModal"
      @login="handleLogin"
      @switchToRegister="switchToRegister"
    />
    <Register
      v-if="isModalOpen && activeModal === 'register'"
      :isOpen="isModalOpen"
      @close="closeModal"
      @register="handleRegister"
      @switchToLogin="switchToLogin"
    />
  </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import Navbar from "@/components/Navbar.vue";
import Login from "@/components/login.vue";
import Register from "@/components/register.vue";

const isLoading = ref(false);
const error = ref(null);
const kiddiePartyProducts = ref([]);
const selectedProduct = ref(null);
const isModalOpen = ref(false);
const isBookingModalOpen = ref(false);
const bookingStep = ref(1);
const bookingForm = ref({
  fullName: '',
  eventDate: '',
  contactNumber: '',
  email: '',
  venueName: '',
  venueAddress: '',
  expectedGuests: '',
  specialRequests: '',
  referralSource: ''
});

const getImageUrl = (imagePath) => {
  return `http://localhost:3000${imagePath}`;
};

const formatPrice = (price) => {
  return '₱' + new Intl.NumberFormat('en-PH').format(price);
};

const openModal = (product) => {
  selectedProduct.value = {
    ...product,
    price: userRole.value === 'user' ? product.price : 'Login to view price'
  };
  isModalOpen.value = true;
};

const closeModal = () => {
  selectedProduct.value = null;
  isModalOpen.value = false;
};

const bookNow = () => {
  isBookingModalOpen.value = true;
};

const closeBookingModal = () => {
  isBookingModalOpen.value = false;
};

const submitBooking = async () => {
  try {
    const response = await fetch('http://localhost:3000/api/bookings', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token.value}`
      },
      body: JSON.stringify(bookingForm.value)
    });
    if (!response.ok) {
      throw new Error('Failed to submit booking');
    }
    alert('Booking submitted successfully!');
    closeBookingModal();
  } catch (error) {
    console.error('Error submitting booking:', error);
  }
};
</script>

<style scoped>
.package-image {
  width: 100%;
  height: 200px;
  object-fit: cover;
}
.package-details {
  padding: 1rem;
}
.package-price {
  font-size: 1.2rem;
  font-weight: 700;
  color: #ff6347;
  margin: 0.5rem 0;
}
.package-link {
  display: inline-block;
  background-color: #ff6347;
  color: white;
  border: none;
  cursor: pointer;
  margin-top: 0.5rem;
  font-size: 1rem;
  text-decoration: none;
  padding: 0.5rem 1rem;
  border-radius: 5px;
  transition: background-color 0.3s ease, color 0.3s ease;
}
.package-link:hover {
  background-color: #ff1100;
}
.loading, .error {
  text-align: center;
  font-size: 1.2rem;
  margin-top: 2rem;
}
.error {
  color: #ff0000;
}

.kiddie-party-package {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
}

.packages-container {
  flex: 1;
}

.section-title {
  font-size: 2rem;
  font-weight: bold;
  text-align: center;
  margin: 1rem 0;
  color: #333; /* Ensure the text color is visible */
}
</style>