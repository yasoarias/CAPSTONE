<template>
  <div id="app">
    <Navbar />
    <router-view></router-view>
  </div>
</template>

<script setup>
import Navbar from "./components/Navbar.vue";
// import { useActivityTracker } from './utils/ActivityTracker';

// const { isActive } = useActivityTracker();
</script>

<style scoped>
#app {
  font-family: sans-serif;
}
</style>
