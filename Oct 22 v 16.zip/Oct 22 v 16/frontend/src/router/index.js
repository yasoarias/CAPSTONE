import { createRouter, createWebHistory } from "vue-router";
import HomePage from "../components/homepage.vue";
import ContactUs from "../components/ContactUs.vue";
import Gallery from "../components/Gallery.vue";
import Packages from "../components/packages.vue";
import WeddingPackage from "../components/packages/WeddingPackage.vue";
import DebutPackage from "../components/packages/DebutPackage.vue";
import KiddiePartyPackage from "../components/packages/KiddiePartyPackage.vue";
import ChristeningPackage from "../components/packages/ChristeningPackage.vue";
import Login from "../components/login.vue";
import AdminDashboard from "../components/AdminDashboard.vue";
import AdminUsers from "@/components/AdminUsers.vue";
import AdminPackages from "@/components/AdminPackages.vue";
import BookingOversight from "@/components/BookingOversight.vue";
import TransactionHistory from "@/components/TransactionHistory.vue";
import AdminSidebar from "@/components/AdminSidebar.vue";
import BookedHistory from "../components/BookedHistory.vue";
import { useAuth } from "../composables/useAuth";

const routes = [
  {
    path: "/",
    name: "Home",
    component: HomePage,
    meta: { requiresGuest: true },
    beforeEnter: (to, from, next) => {
      const userRole = localStorage.getItem("userRole");
      if (userRole === "admin") {
        next("/admin");
      } else if (userRole === "user") {
        next("/gallery");
      } else {
        next();
      }
    },
  },
  {
    path: "/contact",
    name: "Contact",
    component: ContactUs,
    meta: { hideForAdmin: true, hideForLoggedIn: true },
  },
  {
    path: "/gallery",
    name: "Gallery",
    component: Gallery,
  },
  {
    path: "/packages",
    component: Packages,
    children: [
      {
        path: "wedding",
        name: "WeddingPackage",
        component: WeddingPackage,
      },
      {
        path: "debut",
        name: "DebutPackage",
        component: DebutPackage,
      },
      {
        path: "kiddie-party",
        name: "KiddiePartyPackage",
        component: KiddiePartyPackage,
      },
      {
        path: "christening",
        name: "ChristeningPackage",
        component: ChristeningPackage,
      },
    ],
  },
  {
    path: "/login",
    name: "Login",
    component: Login,
    meta: { hideForLoggedIn: true },
  },
  {
    path: "/admin",
    name: "AdminDashboard",
    component: AdminDashboard,
    meta: { requiresAuth: true, requiresAdmin: true },
  },
  {
    path: "/admin/users",
    name: "AdminUsers",
    component: AdminUsers,
    meta: { requiresAuth: true, requiresAdmin: true },
  },
  {
    path: "/admin/packages",
    name: "AdminPackages",
    component: AdminPackages,
    meta: { requiresAuth: true, requiresAdmin: true },
  },
  {
    path: "/admin/transaction-history",
    name: "TransactionHistory",
    component: TransactionHistory,
    meta: { requiresAuth: true, requiresAdmin: true },
  },
  {
    path: "/admin/booking-oversight",
    name: "BookingOversight",
    component: BookingOversight,
    meta: { requiresAuth: true, requiresAdmin: true },
  },
  {
    path: "/booked-history",
    name: "BookedHistory",
    component: BookedHistory,
    meta: { requiresAuth: true },
  },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

router.beforeEach((to, from, next) => {
  const isLoggedIn = !!localStorage.getItem("token");
  const userRole = localStorage.getItem("userRole");

  if (to.meta.requiresAuth && !isLoggedIn) {
    next("/login");
  } else if (to.meta.requiresAdmin && userRole !== "admin") {
    next("/");
  } else {
    next();
  }
});

export default router;
