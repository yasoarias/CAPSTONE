<template>
  <div v-if="isOpen" class="modal-overlay">
    <div class="modal-content">
      <button @click="$emit('close')" class="close-btn">
        <i class="fas fa-times"></i>
      </button>
      <h2>Event Details</h2>
      <div v-if="event" class="event-details">
        <div class="image-container">
          <img
            :src="getCategoryImage(event.package_name)"
            :alt="event.package_name"
            class="package-image"
          />
        </div>
        <div class="details-grid">
          <div class="detail-item">
            <span class="label">Booking ID:</span>
            <span class="value">{{ event.id }}</span>
          </div>
          <div class="detail-item">
            <span class="label">Full Name:</span>
            <span class="value">{{ event.full_name }}</span>
          </div>
          <div class="detail-item">
            <span class="label">Event Date:</span>
            <span class="value">{{ formatDate(event.event_date) }}</span>
          </div>
          <div class="detail-item">
            <span class="label">Contact Number:</span>
            <span class="value">{{ event.contact_number }}</span>
          </div>
          <div class="detail-item">
            <span class="label">Email:</span>
            <span class="value">{{ event.email }}</span>
          </div>
          <div class="detail-item">
            <span class="label">Venue Name:</span>
            <span class="value">{{ event.venue_name }}</span>
          </div>
          <div class="detail-item">
            <span class="label">Expected Guests:</span>
            <span class="value">{{ event.expected_guests }}</span>
          </div>
          <div class="detail-item">
            <span class="label">Category:</span>
            <span class="value">{{ event.package_name }}</span>
          </div>
          <div class="detail-item">
            <span class="label">Package Type:</span>
            <span class="value">{{ event.event_type }}</span>
          </div>
          <div class="detail-item">
            <span class="label">Price:</span>
            <span class="value">₱{{ formatPrice(event.price) }}</span>
          </div>
          <!-- Add this new detail item for special request -->
          <div v-if="event.special_request" class="detail-item">
            <span class="label">Special Request:</span>
            <span class="value">{{ event.special_request }}</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { defineProps, defineEmits } from "vue";

const props = defineProps({
  isOpen: Boolean,
  event: Object,
});

const emit = defineEmits(["close"]);

const formatDate = (dateString) => {
  const options = { year: "numeric", month: "long", day: "numeric" };
  return new Date(dateString).toLocaleDateString(undefined, options);
};

const formatPrice = (price) => {
  return price ? price.toLocaleString() : "N/A";
};

const getCategoryImage = (category) => {
  switch (category.toLowerCase()) {
    case "pearl":
      return "/images/pearl.png";
    case "ruby":
      return "/images/ruby.png";
    case "emerald":
      return "/images/emerald.png";
    case "diamond":
      return "/images/diamond.png";
    default:
      return "/images/default-event.png";
  }
};
</script>

<style scoped>
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
}

.modal-content {
  background-color: white;
  padding: 2rem;
  border-radius: 12px;
  max-width: 600px;
  width: 90%;
  max-height: 90vh;
  overflow-y: auto;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
  position: relative;
}

.close-btn {
  position: absolute;
  top: 1rem;
  right: 1rem;
  background-color: #f8f9fa;
  border: none;
  border-radius: 50%;
  width: 2rem;
  height: 2rem;
  display: flex;
  justify-content: center;
  align-items: center;
  cursor: pointer;
  font-size: 1rem;
  color: #333;
  transition: background-color 0.3s ease, color 0.3s ease;
}

.close-btn:hover {
  background-color: #e9ecef;
  color: #5a67d8;
}

h2 {
  margin-bottom: 1.5rem;
  color: #333;
  font-size: 1.8rem;
}

.event-details {
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
}

.image-container {
  width: 100%;
  height: 200px;
  overflow: hidden;
  border-radius: 8px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
}

.package-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.details-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1rem;
}

.detail-item {
  display: flex;
  flex-direction: column;
  background-color: #f8f9fa;
  padding: 0.8rem;
  border-radius: 8px;
  transition: background-color 0.3s ease;
}

.detail-item:hover {
  background-color: #e9ecef;
}

.label {
  font-weight: bold;
  color: #333;
  margin-bottom: 0.2rem;
}

.value {
  color: #666;
}

.detail-item.special-request {
  background-color: #fff3cd;
}
</style>
