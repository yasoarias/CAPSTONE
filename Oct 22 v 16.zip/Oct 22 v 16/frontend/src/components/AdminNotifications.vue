<template>
  <div class="notifications-wrapper">
    <div class="notifications-container">
      <div class="notifications-header">
        <h3>Notifications</h3>
        <button @click="closeNotifications" class="close-btn" type="button">&times;</button>
      </div>
      <div v-if="notifications.length === 0" class="no-notifications">
        No new notifications
      </div>
      <div v-else class="notifications-list">
        <div v-for="notification in notifications" :key="notification.id" class="notification">
          <span class="icon">
            <i class="fas fa-calendar-alt"></i>
          </span>
          <div class="notification-content">
            <span class="message">
              <strong>{{ notification.userName }}</strong> has requested a booking for 
              <strong>{{ notification.packageType }}</strong> at 
              <strong>{{ notification.venue }}</strong>
            </span>
            <span class="time">{{ formatTime(notification.createdAt) }}</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { useAuth } from '@/composables/useAuth';

const { token } = useAuth();
const notifications = ref([]);

const emit = defineEmits(['close']);

const fetchAdminNotifications = async () => {
  try {
    const response = await fetch('http://localhost:3000/api/admin/notifications', {
      headers: {
        'Authorization': token.value
      }
    });
    if (response.ok) {
      notifications.value = await response.json();
    } else {
      console.error('Failed to fetch admin notifications');
    }
  } catch (error) {
    console.error('Error fetching admin notifications:', error);
  }
};

const formatTime = (timestamp) => {
  const date = new Date(timestamp);
  return date.toLocaleString('en-PH', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: 'numeric',
    minute: 'numeric',
    hour12: true
  });
};

const closeNotifications = (event) => {
  event.preventDefault();
  event.stopPropagation();
  emit('close');
};

onMounted(fetchAdminNotifications);
</script>

<style scoped>
.notifications-wrapper {
  position: absolute;
  top: 100%; /* Position it right below the navbar */
  right: 0;
  z-index: 1000;
  width: 300px; /* Set a fixed width */
}

.notifications-container {
  background-color: white;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-shadow: 0 2px 10px rgba(0,0,0,0.1);
  max-height: 400px;
  overflow-y: auto;
}

.notifications-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px;
  border-bottom: 1px solid #eee;
  background-color: #f8f8f8;
}

.close-btn {
  background: none;
  border: none;
  font-size: 20px;
  cursor: pointer;
}

.notifications-list {
  max-height: 300px;
  overflow-y: auto;
}

.notification {
  padding: 10px;
  border-bottom: 1px solid #eee;
  display: flex;
  align-items: flex-start;
}

.icon {
  margin-right: 10px;
  font-size: 1.2em;
  flex-shrink: 0;
  color: #ff6347; /* Coral color for the icon */
}

.notification-content {
  display: flex;
  flex-direction: column;
  flex-grow: 1;
}

.message {
  margin-bottom: 5px;
}

.time {
  font-size: 0.8em;
  color: #888;
}

.no-notifications {
  padding: 20px;
  text-align: center;
  color: #888;
}

/* Dark mode styles */
:global(.dark-mode) .notifications-container {
  background-color: #333;
  border-color: #555;
}

:global(.dark-mode) .notifications-header {
  background-color: #444;
  border-bottom-color: #555;
}

:global(.dark-mode) .notification {
  border-bottom-color: #555;
}

:global(.dark-mode) .message {
  color: #fff;
}

:global(.dark-mode) .time {
  color: #fff;
}
</style>
