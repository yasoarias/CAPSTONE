import { ref } from "vue";

const token = ref(localStorage.getItem("token"));
const user = ref(JSON.parse(localStorage.getItem("user")));

const setToken = (newToken) => {
  token.value = newToken;
  localStorage.setItem("token", newToken);
};

const setUser = (userData) => {
  user.value = userData;
  localStorage.setItem("user", JSON.stringify(userData));
};

const clearAuth = () => {
  token.value = null;
  user.value = null;
  localStorage.removeItem("token");
  localStorage.removeItem("user");
};

const fetchUserInfo = async () => {
  if (!token.value) {
    console.error("No token found");
    return;
  }
  try {
    const response = await fetch("http://localhost:3000/api/user", {
      headers: {
        Authorization: `Bearer ${token.value}`,
      },
    });
    if (!response.ok) {
      throw new Error("Failed to fetch user info");
    }
    const userData = await response.json();
    setUser(userData);
  } catch (error) {
    console.error("Error fetching user info:", error);
    clearAuth();
  }
};

export function useAuth() {
  return {
    token,
    user,
    setToken,
    setUser,
    clearAuth,
    fetchUserInfo,
  };
}
