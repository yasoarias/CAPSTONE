import { createRouter, createWebHistory } from "vue-router";
import HomePage from "../components/homepage.vue";
import ContactUs from "../components/ContactUs.vue";
import Gallery from "../components/Gallery.vue";
import Packages from "../components/packages.vue";
import WeddingPackage from "../components/packages/WeddingPackage.vue";
import DebutPackage from "../components/packages/DebutPackage.vue";
import KiddiePartyPackage from "../components/packages/KiddiePartyPackage.vue";
import ChristeningPackage from "../components/packages/ChristeningPackage.vue";
import Login from "../components/login.vue";
import AdminDashboard from "../components/AdminDashboard.vue";
import AdminUsers from "@/components/AdminUsers.vue";
import ADTransactionHistory from "@/components/ADTransactionHistory.vue";
import AdminPackages from "@/components/AdminPackages.vue";
import ADBookedOversight from "@/components/ADBookedOversight.vue";
import AdminSidebar from "@/components/AdminSidebar.vue";
import BookedHistory from "@/components/BookedHistory.vue";

const routes = [
  {
    path: "/",
    name: "Home",
    component: HomePage,
    meta: { requiresGuest: true },
    beforeEnter: (to, from, next) => {
      const user = JSON.parse(localStorage.getItem("user"));
      if (user) {
        if (user.role === "admin") {
          next("/admin");
        } else {
          next("/gallery");
        }
      } else {
        next();
      }
    },
  },
  {
    path: "/contact",
    name: "Contact",
    component: ContactUs,
    meta: { hideForAdmin: true, hideForLoggedIn: true },
  },
  {
    path: "/gallery",
    name: "Gallery",
    component: Gallery,
  },
  {
    path: "/packages",
    component: Packages,
    children: [
      {
        path: "wedding",
        name: "WeddingPackage",
        component: WeddingPackage,
      },
      {
        path: "debut",
        name: "DebutPackage",
        component: DebutPackage,
      },
      {
        path: "kiddie-party",
        name: "KiddiePartyPackage",
        component: KiddiePartyPackage,
      },
      {
        path: "christening",
        name: "ChristeningPackage",
        component: ChristeningPackage,
      },
    ],
  },
  {
    path: "/login",
    name: "Login",
    component: Login,
    meta: { hideForLoggedIn: true },
  },
  {
    path: "/admin/sidebar",
    name: "AdminSidebar",
    component: AdminSidebar,
    meta: { requiresAuth: true, requiresAdmin: true },
  },
  {
    path: "/admin",
    name: "AdminDashboard",
    component: AdminDashboard,
    meta: { requiresAuth: true, requiresAdmin: true },
  },
  {
    path: "/admin/users",
    name: "AdminUsers",
    component: AdminUsers,
    meta: { requiresAdmin: true },
  },
  {
    path: "/admin/transaction-history",
    name: "ADTransactionHistory",
    component: ADTransactionHistory,
    meta: { requiresAuth: true, requiresAdmin: true },
  },
  {
    path: "/admin/packages",
    name: "AdminPackages",
    component: AdminPackages,
    meta: { requiresAdmin: true },
  },
  {
    path: "/admin/booked-oversight",
    name: "ADBookedOversight",
    component: ADBookedOversight,
    meta: { requiresAdmin: true },
  },
  {
    path: "/booked-history",
    name: "BookedHistory",
    component: BookedHistory,
    meta: { requiresAuth: true },
  },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

router.beforeEach((to, from, next) => {
  const isAuthenticated = !!localStorage.getItem("token"); // Check if user is logged in
  const userRole = localStorage.getItem("userRole"); // Get user role from localStorage

  if (to.meta.requiresAuth && !isAuthenticated) {
    next({ name: "Login" }); // Redirect to login if not authenticated
  } else if (to.meta.requiresAdmin && userRole !== "admin") {
    next({ name: "Home" }); // Redirect to home if not an admin
  } else {
    next(); // Proceed to the route
  }
});

export default router;
